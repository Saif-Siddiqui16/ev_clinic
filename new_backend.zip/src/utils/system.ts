export const startTime = new Date();
