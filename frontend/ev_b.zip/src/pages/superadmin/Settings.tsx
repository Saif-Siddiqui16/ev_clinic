import { useState } from 'react';
import { FiLock, FiDatabase, FiCheck } from 'react-icons/fi';
import './Settings.css';

const Settings = () => {
    const [twoFactorEnabled] = useState(true);
    const [passwordExpiry] = useState(90);
    const [sessionTimeout] = useState(30);
    const [showSuccessMessage, setShowSuccessMessage] = useState(false);

    const handleUpdateSecurity = () => {
        // Simulate API call
        setShowSuccessMessage(true);
        setTimeout(() => {
            setShowSuccessMessage(false);
        }, 3000);

        alert('Security settings updated successfully!\n\n' +
            `Two-Factor Authentication: ${twoFactorEnabled ? 'Enabled' : 'Disabled'}\n` +
            `Password Expiry: ${passwordExpiry} Days\n` +
            `Session Timeout: ${sessionTimeout} Minutes`);
    };

    const handleManageStorage = () => {
        alert('Storage Management\n\n' +
            'Current Usage: 85% Full\n' +
            'Total Storage: 100 GB\n' +
            'Used: 85 GB\n' +
            'Available: 15 GB\n\n' +
            'Would you like to:\n' +
            '• Clear temporary files\n' +
            '• Archive old records\n' +
            '• Upgrade storage plan');
    };

    const handleDatabaseBackup = () => {
        const confirmed = confirm('Start Database Backup?\n\nThis will create a complete backup of the database. The process may take several minutes.\n\nDo you want to continue?');

        if (confirmed) {
            alert('Database backup initiated!\n\nBackup will be completed in approximately 5-10 minutes.\nYou will receive a notification when the backup is complete.');
        }
    };

    return (
        <div className="settings-page">
            <div className="page-header">
                <div>
                    <h1>Platform Settings</h1>
                    <p>Configure global system parameters and security policies.</p>
                </div>
            </div>

            {showSuccessMessage && (
                <div className="alert alert-success fade-in" style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    padding: '1rem 1.5rem',
                    background: '#E1F9F0',
                    border: '1px solid #10B981',
                    borderRadius: 'var(--radius-sm)',
                    color: '#065F46',
                    marginBottom: '1.5rem'
                }}>
                    <FiCheck size={20} />
                    <span>Security settings updated successfully!</span>
                </div>
            )}

            <div className="settings-grid">
                {/* Security Configuration Card */}
                <div className="settings-card">
                    <div className="card-header">
                        <FiLock />
                        <h3>Security Configuration</h3>
                    </div>

                    <div className="settings-list">
                        <div className="settings-item">
                            <span className="item-label">Two-Factor Authentication</span>
                            <span className={twoFactorEnabled ? "status-enabled" : "status-disabled"}>
                                {twoFactorEnabled ? 'Enabled' : 'Disabled'}
                            </span>
                        </div>

                        <div className="settings-item">
                            <span className="item-label">Password Expiry (Days)</span>
                            <span className="item-value">{passwordExpiry} Days</span>
                        </div>

                        <div className="settings-item">
                            <span className="item-label">Admin Session Timeout</span>
                            <span className="item-value">{sessionTimeout} Mins</span>
                        </div>
                    </div>

                    <div className="card-footer">
                        <button
                            className="btn btn-primary btn-sm"
                            onClick={handleUpdateSecurity}
                        >
                            Update Security
                        </button>
                    </div>
                </div>

                {/* System Maintenance Card */}
                <div className="settings-card">
                    <div className="card-header">
                        <FiDatabase />
                        <h3>System Maintenance</h3>
                    </div>

                    <div className="settings-list">
                        <div className="settings-item">
                            <span className="item-label">Database Backup</span>
                            <span className="text-success">Last: 2h ago</span>
                        </div>

                        <div className="settings-item">
                            <span className="item-label">Storage Usage</span>
                            <span className="text-warning">85% Full</span>
                        </div>
                    </div>

                    <div className="card-footer">
                        <button
                            className="btn btn-secondary btn-sm"
                            onClick={handleManageStorage}
                            style={{ marginRight: '0.75rem' }}
                        >
                            Manage Storage
                        </button>
                        <button
                            className="btn btn-primary btn-sm"
                            onClick={handleDatabaseBackup}
                        >
                            Backup Now
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;
