import { useState, useEffect } from 'react';
import { FiSearch, FiPlus, FiEye, FiCheckCircle, FiChevronRight, FiFileText } from 'react-icons/fi';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import Modal from '../../components/Modal';
import './Dashboard.css';
import './Assessments.css';

const Assessments = () => {
    const { patients, formTemplates, selectedClinic } = useApp() as any;
    const { user } = useAuth() as any;
    const [searchTerm, setSearchTerm] = useState('');
    const [isNewAssessmentOpen, setIsNewAssessmentOpen] = useState(false);
    const [assessmentStep, setAssessmentStep] = useState(1); // 1: Template selection, 2: Form filling

    // Selection state
    const [selectedPatientId, setSelectedPatientId] = useState('');
    const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
    const [formData, setFormData] = useState<Record<string, any>>({});

    // Filter templates for this clinic
    const clinicTemplates = formTemplates.filter((t: any) => t.clinicId === selectedClinic?.id || !t.clinicId);

    // Mock assessments data (in real app, this would be in AppContext)
    const [assessments, setAssessments] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_assessments');
        return saved ? JSON.parse(saved) : [
            {
                id: 1,
                patientName: 'John Doe',
                patientId: 1,
                date: '2024-01-10',
                templateName: 'General Patient Assessment',
                status: 'Completed'
            }
        ];
    });

    useEffect(() => localStorage.setItem('ev_assessments', JSON.stringify(assessments)), [assessments]);

    const handleStartAssessment = (template: any) => {
        setSelectedTemplate(template);
        setAssessmentStep(2);
        // Initialize form data
        const initialData: Record<string, any> = {};
        template.fields.forEach((f: any) => {
            initialData[f.id] = '';
        });
        setFormData(initialData);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const patient = (patients as any[]).find(p => p.id === Number(selectedPatientId));
        const newAssessment = {
            id: Date.now(),
            patientId: Number(selectedPatientId),
            patientName: patient?.name || 'Unknown',
            templateId: selectedTemplate.id,
            templateName: selectedTemplate.name,
            date: new Date().toISOString().split('T')[0],
            data: formData,
            status: 'Completed',
            doctorId: user.id
        };
        setAssessments([newAssessment, ...assessments]);
        setIsNewAssessmentOpen(false);
        resetForm();
    };

    const resetForm = () => {
        setAssessmentStep(1);
        setSelectedPatientId('');
        setSelectedTemplate(null);
        setFormData({});
    };

    const filteredAssessments = assessments.filter(assessment =>
        assessment.patientName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="doctor-dashboard">
            <div className="assessments-header">
                <div>
                    <h1 className="assessments-title">Assessments</h1>
                    <p className="assessments-subtitle">Create and manage patient assessments</p>
                </div>
                <button className="btn btn-primary btn-with-icon" onClick={() => setIsNewAssessmentOpen(true)}>
                    <FiPlus />
                    <span>New Assessment</span>
                </button>
            </div>

            <div className="assessments-search-card">
                <div className="search-stats-row">
                    <div className="search-box-left">
                        <FiSearch className="search-icon-small" />
                        <input
                            type="text"
                            placeholder="Search by patient name..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="search-input-minimal"
                        />
                    </div>
                </div>
            </div>

            <div className="assessments-grid">
                {filteredAssessments.length > 0 ? (
                    filteredAssessments.map(assessment => (
                        <div key={assessment.id} className="assessment-card">
                            <div className="assessment-header-row">
                                <div className="assessment-patient-info">
                                    <h3 className="assessment-patient-name">{assessment.patientName}</h3>
                                    <p className="assessment-date">{assessment.date} • {assessment.templateName}</p>
                                </div>
                                <span className="status-badge completed">
                                    <FiCheckCircle size={14} />
                                    {assessment.status}
                                </span>
                            </div>
                            <div className="assessment-actions">
                                <button className="action-btn-icon">
                                    <FiEye />
                                </button>
                                <button className="action-btn-icon">
                                    <FiFileText />
                                </button>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="empty-state-assessments">
                        <div className="empty-icon-large">
                            <FiCheckCircle />
                        </div>
                        <h3>No assessments found</h3>
                    </div>
                )}
            </div>

            <Modal
                isOpen={isNewAssessmentOpen}
                onClose={() => { setIsNewAssessmentOpen(false); resetForm(); }}
                title="New Clinical Assessment"
                size="lg"
            >
                {assessmentStep === 1 ? (
                    <div className="assessment-init">
                        <div className="form-group mb-lg">
                            <label>1. Select Patient *</label>
                            <select
                                required
                                value={selectedPatientId}
                                onChange={e => setSelectedPatientId(e.target.value)}
                            >
                                <option value="">Choose patient...</option>
                                {(patients as any[]).map((p: any) => (
                                    <option key={p.id} value={p.id}>{p.name} (P-{p.id})</option>
                                ))}
                            </select>
                        </div>

                        <label>2. Choose Assessment Template *</label>
                        <div className="templates-selection-grid mt-sm">
                            {clinicTemplates.map((template: any) => (
                                <button
                                    key={template.id}
                                    className="template-select-card"
                                    onClick={() => handleStartAssessment(template)}
                                    disabled={!selectedPatientId}
                                >
                                    <div className="template-icon"><FiFileText /></div>
                                    <div className="template-info">
                                        <h4>{template.name}</h4>
                                        <p>{template.fields.length} points of assessment</p>
                                    </div>
                                    <FiChevronRight className="arrow" />
                                </button>
                            ))}
                        </div>
                    </div>
                ) : (
                    <form className="dynamic-assessment-form" onSubmit={handleSubmit}>
                        <div className="form-header-minimal">
                            <h3>{selectedTemplate.name}</h3>
                            <p>Patient: <strong>{(patients as any[]).find(p => p.id === Number(selectedPatientId))?.name}</strong></p>
                        </div>

                        <div className="dynamic-fields-scroll mt-lg">
                            {selectedTemplate.fields.map((field: any) => (
                                <div key={field.id} className="form-group">
                                    <label>
                                        {field.label} {field.required && <span className="text-danger">*</span>}
                                    </label>
                                    {field.type === 'text' && (
                                        <input
                                            type="text"
                                            required={field.required}
                                            placeholder={field.placeholder}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        />
                                    )}
                                    {field.type === 'textarea' && (
                                        <textarea
                                            rows={3}
                                            required={field.required}
                                            placeholder={field.placeholder}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        ></textarea>
                                    )}
                                    {field.type === 'number' && (
                                        <input
                                            type="number"
                                            required={field.required}
                                            placeholder={field.placeholder}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        />
                                    )}
                                    {field.type === 'dropdown' && (
                                        <select
                                            required={field.required}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        >
                                            <option value="">Select...</option>
                                            {field.options?.map((opt: string) => (
                                                <option key={opt} value={opt}>{opt}</option>
                                            ))}
                                        </select>
                                    )}
                                    {field.type === 'date' && (
                                        <input
                                            type="date"
                                            required={field.required}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        />
                                    )}
                                </div>
                            ))}
                        </div>

                        <div className="modal-actions mt-xl">
                            <button type="button" className="btn btn-secondary" onClick={() => setAssessmentStep(1)}>Back</button>
                            <button type="submit" className="btn btn-primary">
                                <FiCheckCircle className="mr-xs" /> Complete Assessment
                            </button>
                        </div>
                    </form>
                )}
            </Modal>
        </div>
    );
};

export default Assessments;
