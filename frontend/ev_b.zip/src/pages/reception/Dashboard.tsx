import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { FiUsers, FiCalendar, FiActivity, FiClock, FiCheck, FiPlus, FiUserPlus, FiCreditCard } from 'react-icons/fi';
import Modal from '../../components/Modal';
import './Dashboard.css';

const ReceptionDashboard = () => {
    const { bookings, patients, staff } = useApp() as any;
    const { selectedClinic } = useAuth() as any;
    const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
    const [isWalkinModalOpen, setIsWalkinModalOpen] = useState(false);

    // Strict Data Isolation - Filter by active clinic
    const clinicBookings = (bookings as any[]).filter(b => b.clinicId === selectedClinic?.id);
    const clinicPatients = patients; // In a real app, patients would also have clinicId or association
    const clinicStaff = staff.filter((s: any) => s.clinicId === selectedClinic?.id || (s.clinics || []).includes(selectedClinic?.id));

    const stats = [
        { label: "Today's Appointments", value: clinicBookings.length, icon: <FiCalendar />, color: '#3F46B8' },
        { label: 'Total Patients', value: clinicPatients.length, icon: <FiUsers />, color: '#10B981' },
        { label: 'Doctors On-Duty', value: clinicStaff.filter((s: any) => (s.roles || [s.role]).includes('doctor')).length, icon: <FiActivity />, color: '#F59E0B' },
        { label: 'Checked-In', value: clinicBookings.filter((b: any) => b.status === 'Checked In').length, icon: <FiCheck />, color: '#8B5CF6' },
    ];

    return (
        <div className="reception-dashboard">
            <div className="dashboard-welcome">
                <div>
                    <h1>Reception Dashboard</h1>
                    <p>Manage appointments, patient check-ins, and daily operations</p>
                </div>
                <div className="header-actions">
                    <button className="btn btn-secondary btn-with-icon" onClick={() => setIsWalkinModalOpen(true)}>
                        <FiPlus /> <span>Walk-in</span>
                    </button>
                    <button className="btn btn-primary btn-with-icon" onClick={() => setIsAppointmentModalOpen(true)}>
                        <FiPlus /> <span>New Appointment</span>
                    </button>
                </div>
            </div>

            <div className="stats-grid">
                {stats.map((stat, index) => (
                    <div
                        key={index}
                        className={`stat-card fade-in-up ${index === 1 ? 'primary-border' : ''}`}
                        style={{ animationDelay: `${index * 0.1}s` }}
                    >
                        <div className="stat-icon-square" style={{ background: `${stat.color}15`, color: stat.color }}>{stat.icon}</div>
                        <p className="stat-label">{stat.label}</p>
                        <h3 className="stat-value">{stat.value}</h3>
                    </div>
                ))}
            </div>

            <div className="dashboard-sections grid-2 mt-lg">
                <div className="section-card card">
                    <div className="section-header-centered">
                        <h3>Today's Schedule</h3>
                        <button className="text-link-blue">View All &rarr;</button>
                    </div>
                    <div className="schedule-list mt-md">
                        {clinicBookings.length === 0 ? (
                            <p className="empty-msg">No appointments scheduled for today.</p>
                        ) : (
                            clinicBookings.slice(0, 4).map((booking: any) => (
                                <div key={booking.id} className="schedule-row">
                                    <div className="schedule-time">
                                        <FiClock /> {booking.time}
                                    </div>
                                    <div className="schedule-patient">
                                        {(patients as any[]).find(p => p.id === parseInt(booking.patientId))?.name || 'Unknown Patient'}
                                    </div>
                                    <div className="schedule-doctor">
                                        Dr. Unassigned
                                    </div>
                                    <div className={`status-pill-mini ${booking.status.toLowerCase().replace(' ', '-')}`}>
                                        {booking.status}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                <div className="section-card card">
                    <div className="section-header-centered">
                        <h3>Quick Actions</h3>
                    </div>
                    <div className="quick-actions-list mt-md">
                        <div className="action-row-block" onClick={() => setIsAppointmentModalOpen(true)}>
                            <div className="action-icon-dark"><FiCalendar /></div>
                            <div className="action-text">
                                <strong>Schedule Appointment</strong>
                                <span>Book new patient appointment</span>
                            </div>
                        </div>
                        <div className="action-row-block">
                            <div className="action-icon-dark"><FiUserPlus /></div>
                            <div className="action-text">
                                <strong>Register Patient</strong>
                                <span>Add new patient to system</span>
                            </div>
                        </div>
                        <div className="action-row-block" onClick={() => setIsWalkinModalOpen(true)}>
                            <div className="action-icon-dark"><FiUsers /></div>
                            <div className="action-text">
                                <strong>Walk-in Patient</strong>
                                <span>Quick registration for walk-ins</span>
                            </div>
                        </div>
                        <div className="action-row-block">
                            <div className="action-icon-dark"><FiCreditCard /></div>
                            <div className="action-text">
                                <strong>Process Billing</strong>
                                <span>Create invoice and payments</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Schedule Appointment Modal */}
            <Modal
                isOpen={isAppointmentModalOpen}
                onClose={() => setIsAppointmentModalOpen(false)}
                title="Schedule Appointment"
            >
                <form className="modal-form" onSubmit={(e) => { e.preventDefault(); setIsAppointmentModalOpen(false); }}>
                    <div className="form-group">
                        <label>Patient *</label>
                        <select required>
                            <option value="">Select Patient</option>
                            {patients.map((p: any) => (
                                <option key={p.id} value={p.id}>{p.name}</option>
                            ))}
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Doctor/Admission *</label>
                        <select required>
                            <option value="">Select Provider</option>
                            {clinicStaff.filter((s: any) => (s.roles || [s.role]).includes('doctor') || (s.roles || [s.role]).includes('admission')).map((d: any) => (
                                <option key={d.id} value={d.id}>{d.name}</option>
                            ))}
                        </select>
                    </div>
                    <div className="form-grid grid-2">
                        <div className="form-group">
                            <label>Date *</label>
                            <input type="date" defaultValue="2026-01-12" required />
                        </div>
                        <div className="form-group">
                            <label>Time *</label>
                            <select required>
                                <option value="09:00">09:00</option>
                                <option value="09:30">09:30</option>
                                <option value="10:00">10:00</option>
                                <option value="10:30">10:30</option>
                            </select>
                        </div>
                    </div>
                    <div className="form-group">
                        <label>Service Type *</label>
                        <select required>
                            <option value="Consultation">Consultation</option>
                            <option value="Follow-up">Follow-up</option>
                            <option value="Emergency">Emergency</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Notes</label>
                        <textarea placeholder="Additional notes..."></textarea>
                    </div>
                    <div className="modal-actions-refined">
                        <button type="button" className="btn-cancel" onClick={() => setIsAppointmentModalOpen(false)}>Cancel</button>
                        <button type="submit" className="btn-save">
                            <FiCheck /> Schedule Appointment
                        </button>
                    </div>
                </form>
            </Modal>

            {/* Walk-in Patient Modal */}
            <Modal
                isOpen={isWalkinModalOpen}
                onClose={() => setIsWalkinModalOpen(false)}
                title="Walk-in Patient"
            >
                <form className="modal-form" onSubmit={(e) => { e.preventDefault(); setIsWalkinModalOpen(false); }}>
                    <div className="form-group">
                        <label>Patient Name *</label>
                        <input type="text" placeholder="Enter patient name" required />
                    </div>
                    <div className="form-group">
                        <label>Phone Number *</label>
                        <input type="text" placeholder="+971 50 123 4567" required />
                    </div>
                    <div className="form-group">
                        <label>Reason for Visit</label>
                        <textarea placeholder="Brief description" rows={3}></textarea>
                    </div>
                    <div className="modal-actions-refined">
                        <button type="button" className="btn-cancel" onClick={() => setIsWalkinModalOpen(false)}>Cancel</button>
                        <button type="submit" className="btn-save">Register Walk-in</button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default ReceptionDashboard;
