import { useState } from 'react';
import { FiSearch, FiPlus, FiMail, FiMapPin, FiEye, FiEdit, FiCheck } from 'react-icons/fi';
import { useApp } from '../../context/AppContext';
import Modal from '../../components/Modal';
import './Patients.css';

const PatientManagement = () => {
    const { patients } = useApp() as any;
    const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [selectedPatient, setSelectedPatient] = useState<any>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const handleViewPatient = (patient: any) => {
        setSelectedPatient(patient);
        setIsViewModalOpen(true);
    };

    const handleEditPatient = (patient: any) => {
        setSelectedPatient(patient);
        setIsEditModalOpen(true);
    };

    const filteredPatients = patients.filter((p: any) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.phone?.includes(searchTerm) ||
        `P-${p.id}`.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="patient-management-page">
            <div className="page-header">
                <div>
                    <h1>Patient Management</h1>
                    <p>Register and manage patient records</p>
                </div>
                <button className="btn btn-primary btn-with-icon" onClick={() => setIsRegisterModalOpen(true)}>
                    <FiPlus />
                    <span>Register Patient</span>
                </button>
            </div>

            <div className="search-stats-card card">
                <div className="central-search">
                    <FiSearch />
                    <input
                        type="text"
                        placeholder="Search by name, phone, or ID..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <div className="stats-mini-row">
                    <div className="stat-mini-item">
                        <span className="stat-mini-value">{patients.length}</span>
                        <span className="stat-mini-label">Total Patients</span>
                    </div>
                    <div className="stat-mini-item">
                        <span className="stat-mini-value">{filteredPatients.length}</span>
                        <span className="stat-mini-label">Search Results</span>
                    </div>
                </div>
            </div>

            <div className="patient-cards-grid mt-lg">
                {filteredPatients.map((patient: any) => (
                    <div key={patient.id} className="patient-profile-card card">
                        <div className="card-top">
                            <div className="patient-avatar-circle">
                                {patient.name.charAt(0)}
                            </div>
                            <div className="patient-basic-info">
                                <h3>{patient.name}</h3>
                                <div className="patient-id-tag">ID: P-{patient.id}</div>
                            </div>
                        </div>
                        <div className="card-divider"></div>
                        <div className="patient-contact-details">
                            <div className="contact-row">
                                <div className="contact-info-block">
                                    <FiMail size={16} />
                                    <span>{patient.email || 'No email provided'}</span>
                                </div>
                            </div>
                            <div className="contact-row">
                                <div className="contact-info-block">
                                    <FiMapPin size={16} />
                                    <span>123 Main St, City</span>
                                </div>
                            </div>
                        </div>
                        <div className="card-actions-row">
                            <button className="action-icon-btn" onClick={() => handleViewPatient(patient)}><FiEye /></button>
                            <button className="action-icon-btn" onClick={() => handleEditPatient(patient)}><FiEdit /></button>
                        </div>
                    </div>
                ))}
            </div>

            {/* Register New Patient Modal */}
            <Modal
                isOpen={isRegisterModalOpen}
                onClose={() => setIsRegisterModalOpen(false)}
                title="Register New Patient"
                size="lg"
            >
                <form className="modal-form" onSubmit={(e) => { e.preventDefault(); setIsRegisterModalOpen(false); }}>
                    <h4 className="form-section-title">Personal Information</h4>
                    <div className="form-group">
                        <label>Full Name *</label>
                        <input type="text" placeholder="John Doe" required />
                    </div>
                    <div className="form-grid grid-2">
                        <div className="form-group">
                            <label>Phone Number *</label>
                            <input type="text" placeholder="+971 50 123 4567" required />
                        </div>
                        <div className="form-group">
                            <label>Email</label>
                            <input type="email" placeholder="john@example.com" />
                        </div>
                    </div>
                    <div className="form-grid grid-2">
                        <div className="form-group">
                            <label>Date of Birth</label>
                            <input type="date" placeholder="mm/dd/yyyy" />
                        </div>
                        <div className="form-group">
                            <label>Gender</label>
                            <select>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div className="form-group">
                        <label>Address</label>
                        <textarea placeholder="Street address, city, country" rows={3}></textarea>
                    </div>

                    <h4 className="form-section-title">Emergency Contact</h4>
                    <div className="form-grid grid-2">
                        <div className="form-group">
                            <label>Contact Name</label>
                            <input type="text" placeholder="Emergency contact name" />
                        </div>
                        <div className="form-group">
                            <label>Contact Phone</label>
                            <input type="text" placeholder="Emergency phone" />
                        </div>
                    </div>

                    <h4 className="form-section-title">Medical Information</h4>
                    <div className="form-group">
                        <label>Medical History</label>
                        <textarea placeholder="Previous conditions, surgeries, etc." rows={3}></textarea>
                    </div>
                    <div className="form-group">
                        <label>Allergies</label>
                        <input type="text" placeholder="Drug allergies, food allergies, etc." />
                    </div>

                    <div className="modal-actions-refined">
                        <button type="button" className="btn-cancel" onClick={() => setIsRegisterModalOpen(false)}>Cancel</button>
                        <button type="submit" className="btn-save">
                            <FiCheck /> Save Patient Record
                        </button>
                    </div>
                </form>
            </Modal>

            {/* View Patient Modal */}
            <Modal
                isOpen={isViewModalOpen}
                onClose={() => setIsViewModalOpen(false)}
                title="Patient Details"
                size="lg"
            >
                {selectedPatient && (
                    <div className="patient-view-content">
                        <div className="patient-view-header">
                            <div className="patient-avatar-circle-large">
                                {selectedPatient.name.charAt(0)}
                            </div>
                            <div>
                                <h2>{selectedPatient.name}</h2>
                                <div className="patient-id-tag">ID: P-{selectedPatient.id}</div>
                            </div>
                        </div>

                        <div className="patient-info-section">
                            <h4 className="form-section-title">Personal Information</h4>
                            <div className="info-grid">
                                <div className="info-item">
                                    <label>Age</label>
                                    <p>{selectedPatient.age || 'N/A'}</p>
                                </div>
                                <div className="info-item">
                                    <label>Gender</label>
                                    <p>{selectedPatient.gender || 'N/A'}</p>
                                </div>
                                <div className="info-item">
                                    <label>Phone</label>
                                    <p>{selectedPatient.contact || selectedPatient.phone || 'N/A'}</p>
                                </div>
                                <div className="info-item">
                                    <label>Email</label>
                                    <p>{selectedPatient.email || 'N/A'}</p>
                                </div>
                                <div className="info-item full-width">
                                    <label>Address</label>
                                    <p>{selectedPatient.address || 'N/A'}</p>
                                </div>
                            </div>
                        </div>

                        <div className="patient-info-section">
                            <h4 className="form-section-title">Medical Information</h4>
                            <div className="info-grid">
                                <div className="info-item full-width">
                                    <label>Medical History</label>
                                    <p>{selectedPatient.medicalHistory || 'No medical history recorded'}</p>
                                </div>
                                <div className="info-item full-width">
                                    <label>Last Visit</label>
                                    <p>{selectedPatient.lastVisit || 'No visits recorded'}</p>
                                </div>
                            </div>
                        </div>

                        <div className="modal-actions-refined">
                            <button type="button" className="btn-cancel" onClick={() => setIsViewModalOpen(false)}>Close</button>
                            <button type="button" className="btn-save" onClick={() => {
                                setIsViewModalOpen(false);
                                handleEditPatient(selectedPatient);
                            }}>
                                <FiEdit /> Edit Patient
                            </button>
                        </div>
                    </div>
                )}
            </Modal>

            {/* Edit Patient Modal */}
            <Modal
                isOpen={isEditModalOpen}
                onClose={() => setIsEditModalOpen(false)}
                title="Edit Patient Information"
                size="lg"
            >
                {selectedPatient && (
                    <form className="modal-form" onSubmit={(e) => { e.preventDefault(); setIsEditModalOpen(false); }}>
                        <h4 className="form-section-title">Personal Information</h4>
                        <div className="form-group">
                            <label>Full Name *</label>
                            <input type="text" defaultValue={selectedPatient.name} required />
                        </div>
                        <div className="form-grid grid-2">
                            <div className="form-group">
                                <label>Phone Number *</label>
                                <input type="text" defaultValue={selectedPatient.contact || selectedPatient.phone} required />
                            </div>
                            <div className="form-group">
                                <label>Email</label>
                                <input type="email" defaultValue={selectedPatient.email} />
                            </div>
                        </div>
                        <div className="form-grid grid-2">
                            <div className="form-group">
                                <label>Age</label>
                                <input type="number" defaultValue={selectedPatient.age} />
                            </div>
                            <div className="form-group">
                                <label>Gender</label>
                                <select defaultValue={selectedPatient.gender}>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div className="form-group">
                            <label>Address</label>
                            <textarea defaultValue={selectedPatient.address} rows={3}></textarea>
                        </div>

                        <h4 className="form-section-title">Medical Information</h4>
                        <div className="form-group">
                            <label>Medical History</label>
                            <textarea defaultValue={selectedPatient.medicalHistory} placeholder="Previous conditions, surgeries, etc." rows={3}></textarea>
                        </div>

                        <div className="modal-actions-refined">
                            <button type="button" className="btn-cancel" onClick={() => setIsEditModalOpen(false)}>Cancel</button>
                            <button type="submit" className="btn-save">
                                <FiCheck /> Save Changes
                            </button>
                        </div>
                    </form>
                )}
            </Modal>
        </div>
    );
};

export default PatientManagement;

