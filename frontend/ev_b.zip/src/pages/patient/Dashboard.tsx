import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { FiCalendar, FiActivity, FiInfo } from 'react-icons/fi';
import { NavLink } from 'react-router-dom';
import './PatientBooking.css';

const PatientDashboard = () => {
    const { user } = useAuth() as any;
    const { bookings } = useApp() as any;

    const patientBookings = bookings.filter((b: any) =>
        b.patientId === user?.id || b.email === user?.email
    ).sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    const nextAppointment = patientBookings.find((b: any) => b.status === 'Approved');

    return (
        <div className="patient-dashboard fade-in">
            <div className="page-header">
                <div>
                    <h1>Welcome back, {user?.name || 'Patient'}</h1>
                    <p>Manage your health journey and upcoming appointments.</p>
                </div>
                <NavLink to="/patient/book" className="btn btn-primary btn-with-icon">
                    <FiCalendar /> <span>Book New Appointment</span>
                </NavLink>
            </div>

            <div className="stats-grid mt-lg">
                <div className="stat-card">
                    <div className="stat-icon-square" style={{ background: '#3F46B815', color: '#3F46B8' }}><FiCalendar /></div>
                    <p className="stat-label">Total Bookings</p>
                    <h3 className="stat-value">{patientBookings.length}</h3>
                </div>
                <div className="stat-card">
                    <div className="stat-icon-square" style={{ background: '#10B98115', color: '#10B981' }}><FiActivity /></div>
                    <p className="stat-label">Last Status</p>
                    <h3 className="stat-value" style={{ fontSize: '1.25rem' }}>{patientBookings[0]?.status || 'No history'}</h3>
                </div>
            </div>

            <div className="dashboard-sections mt-lg">
                <div className="section-card card">
                    <h3>Upcoming Appointment</h3>
                    {nextAppointment ? (
                        <div className="next-booking mt-md p-md accent-bg radius-sm">
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <p className="text-secondary mb-xs">Date & Time</p>
                                    <strong>{nextAppointment.date} at {nextAppointment.time}</strong>
                                </div>
                                <div className="status-pill approved">Approved</div>
                            </div>
                        </div>
                    ) : (
                        <div className="empty-state mt-md">
                            <FiInfo />
                            <p>No upcoming approved appointments.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PatientDashboard;
