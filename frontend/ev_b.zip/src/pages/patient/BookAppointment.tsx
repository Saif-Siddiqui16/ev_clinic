import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { FiCalendar, FiUser, FiMail, FiPhone, FiCheck, FiClock, FiActivity } from 'react-icons/fi';
import './PatientBooking.css';

const BookAppointment = () => {
    const { staff, addBooking, logAction } = useApp() as any;
    const { user, selectedClinic } = useAuth() as any;
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [bookingRef, setBookingRef] = useState('');
    const [formData, setFormData] = useState({
        patientName: user?.name || '',
        email: user?.email || '',
        phone: '',
        doctorId: '',
        date: '',
        time: '',
    });

    const bookableStaff = staff.filter((s: any) =>
        (s.roles || [s.role]).includes('doctor') ||
        (s.roles || [s.role]).includes('admission')
    );

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        const refId = `EV-${Math.floor(100000 + Math.random() * 900000)}`;
        setBookingRef(refId);

        const newBooking = {
            ...formData,
            id: Date.now(),
            referenceId: refId,
            patientId: user?.id || Date.now(), // Use existing user ID or temporary
            clinicId: selectedClinic?.id || 1,
            status: 'Pending Approval',
            timestamp: new Date().toISOString(),
        };

        addBooking(newBooking);
        logAction('New Appointment Request', user?.name || 'Patient', { referenceId: refId });

        setIsSubmitted(true);
    };

    const timeSlots = [
        '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
        '11:00 AM', '11:30 AM', '02:00 PM', '02:30 PM',
        '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM'
    ];

    if (isSubmitted) {
        return (
            <div className="confirmation-view fade-in">
                <div className="card text-center success-card">
                    <div className="success-icon-large mb-md">
                        <FiCheck />
                    </div>
                    <h2 className="mb-sm">Appointment Requested!</h2>
                    <p className="mb-md">Your appointment request has been sent for approval.</p>

                    <div className="ref-id-badge mb-lg">
                        <span>Booking Reference ID:</span>
                        <strong>{bookingRef}</strong>
                    </div>

                    <div className="booking-summary card mb-lg">
                        <h3>Appointment Summary</h3>
                        <div className="summary-details">
                            <div className="summary-item">
                                <span className="label">Patient:</span>
                                <span className="value">{formData.patientName}</span>
                            </div>
                            <div className="summary-item">
                                <span className="label">Doctor/Admission:</span>
                                <span className="value">{bookableStaff.find((d: any) => d.id === parseInt(formData.doctorId))?.name || 'Selected Provider'}</span>
                            </div>
                            <div className="summary-item">
                                <span className="label">Date & Time:</span>
                                <span className="value">{formData.date} at {formData.time}</span>
                            </div>
                            <div className="summary-item">
                                <span className="label">Status:</span>
                                <span className="status-badge pending">Pending Approval</span>
                            </div>
                        </div>
                    </div>

                    <div className="action-buttons">
                        <button className="btn btn-primary mr-sm" onClick={() => window.location.href = '/patient/status'}>
                            View Appointment Status
                        </button>
                        <button className="btn btn-secondary" onClick={() => setIsSubmitted(false)}>
                            Book Another Appointment
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="booking-page-container fade-in">
            <div className="booking-header-flex">
                <h1 className="booking-title">Book Your Appointment</h1>
                <p className="booking-subtitle">Fill in the details below to request an appointment with our specialists.</p>
            </div>

            <div className="booking-card-v2">
                <form onSubmit={handleSubmit} className="appointment-form-v2">
                    <div className="form-grid-v2">
                        <div className="form-group">
                            <label><FiUser /> Patient Name *</label>
                            <input
                                type="text"
                                name="patientName"
                                value={formData.patientName}
                                onChange={handleInputChange}
                                required
                                placeholder="John Patient"
                            />
                        </div>

                        <div className="form-group">
                            <label><FiMail /> Email Address *</label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                required
                                placeholder="patient@demo.com"
                            />
                        </div>

                        <div className="form-group">
                            <label><FiPhone /> Contact Number *</label>
                            <div className="phone-input-v2">
                                <select className="country-code-v2" defaultValue="+91">
                                    <option value="+91">+91 (IN)</option>
                                </select>
                                <input
                                    type="tel"
                                    name="phone"
                                    value={formData.phone}
                                    onChange={handleInputChange}
                                    required
                                    placeholder="Enter mobile number"
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <label><FiActivity /> Select Doctor or Admission *</label>
                            <select
                                name="doctorId"
                                value={formData.doctorId}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="">Choose a provider</option>
                                {bookableStaff.map((member: any) => (
                                    <option key={member.id} value={member.id}>
                                        {member.name} - {member.specialty || member.department || (member.roles.includes('admission') ? 'Admission' : 'General')}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className="form-group">
                            <label><FiCalendar /> Preferred Date *</label>
                            <input
                                type="date"
                                id="date-picker-v2"
                                name="date"
                                value={formData.date}
                                onChange={handleInputChange}
                                min={new Date().toISOString().split('T')[0]}
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label><FiClock /> Select Time Slot *</label>
                            {!formData.doctorId || !formData.date ? (
                                <div className="slot-placeholder-v2">
                                    Please select doctor and date first
                                </div>
                            ) : (
                                <div className="slots-grid-compact-v2">
                                    {timeSlots.map((slot) => (
                                        <button
                                            key={slot}
                                            type="button"
                                            className={`time-slot-pill-v2 ${formData.time === slot ? 'active' : ''}`}
                                            onClick={() => setFormData(prev => ({ ...prev, time: slot }))}
                                        >
                                            {slot}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="form-submit-v2 mt-xl">
                        <button type="submit" className="btn-request-v2">
                            <FiCheck /> Request Appointment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default BookAppointment;
