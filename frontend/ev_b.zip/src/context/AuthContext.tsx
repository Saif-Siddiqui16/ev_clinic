import React, { createContext, useContext, useState, useEffect } from 'react';
import { findUserByCredentials } from '../data/users';
import { getClinicsByIds } from '../data/clinics';

interface AuditLog {
    timestamp: string;
    email: string;
    success: boolean;
    ip: string;
    device: string;
    selectedClinic?: string;
    roles?: string[];
    reason?: string;
}

interface AuthContextType {
    user: any;
    selectedClinic: any;
    isAuthenticated: boolean;
    loading: boolean;
    failedAttempts: number;
    lockoutUntil: number | null;
    showCaptcha: boolean;
    login: (email: string, password: string, captchaValue?: string) => {
        success: boolean;
        user?: any;
        error?: string;
        requiresCaptcha?: boolean;
        lockedUntil?: number;
    };
    logout: () => void;
    selectClinic: (clinic: any) => void;
    getUserClinics: () => any[];
    resetFailedAttempts: () => void;
    getAuditLogs: () => AuditLog[];
}

const AuthContext = createContext<AuthContextType | null>(null);

// Helper to get device info
const getDeviceInfo = () => {
    const ua = navigator.userAgent;
    if (/mobile/i.test(ua)) return 'Mobile';
    if (/tablet/i.test(ua)) return 'Tablet';
    return 'Desktop';
};

// Helper to simulate IP (in real app, get from backend)
const getClientIP = () => {
    return '192.168.1.' + Math.floor(Math.random() * 255);
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
    const [user, setUser] = useState<any>(null);
    const [selectedClinic, setSelectedClinic] = useState<any>(null);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [loading, setLoading] = useState(true);
    const [failedAttempts, setFailedAttempts] = useState(0);
    const [lockoutUntil, setLockoutUntil] = useState<number | null>(null);
    const [showCaptcha, setShowCaptcha] = useState(false);
    const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

    // Check for existing session and lockout on mount
    useEffect(() => {
        const storedUser = localStorage.getItem('ev_user');
        const storedClinic = localStorage.getItem('ev_clinic');
        const storedLockout = localStorage.getItem('ev_lockout');
        const storedAttempts = localStorage.getItem('ev_attempts');
        const storedLogs = localStorage.getItem('ev_audit_logs');

        if (storedUser) {
            setUser(JSON.parse(storedUser));
            setIsAuthenticated(true);
        }

        if (storedClinic) {
            setSelectedClinic(JSON.parse(storedClinic));
        }

        if (storedLockout) {
            const lockoutTime = parseInt(storedLockout);
            if (lockoutTime > Date.now()) {
                setLockoutUntil(lockoutTime);
            } else {
                localStorage.removeItem('ev_lockout');
                localStorage.removeItem('ev_attempts');
            }
        }

        if (storedAttempts) {
            const attempts = parseInt(storedAttempts);
            setFailedAttempts(attempts);
            if (attempts >= 3) {
                setShowCaptcha(true);
            }
        }

        if (storedLogs) {
            setAuditLogs(JSON.parse(storedLogs));
        }

        setLoading(false);
    }, []);

    // Auto-clear lockout when time expires
    useEffect(() => {
        if (lockoutUntil && lockoutUntil > Date.now()) {
            const timeout = setTimeout(() => {
                setLockoutUntil(null);
                setFailedAttempts(0);
                setShowCaptcha(false);
                localStorage.removeItem('ev_lockout');
                localStorage.removeItem('ev_attempts');
            }, lockoutUntil - Date.now());

            return () => clearTimeout(timeout);
        }
    }, [lockoutUntil]);

    const addAuditLog = (log: AuditLog) => {
        const newLogs = [log, ...auditLogs].slice(0, 100); // Keep last 100 logs
        setAuditLogs(newLogs);
        localStorage.setItem('ev_audit_logs', JSON.stringify(newLogs));
    };

    const login = (email: string, password: string, captchaValue?: string) => {
        // Check if account is locked
        if (lockoutUntil && lockoutUntil > Date.now()) {
            const remainingTime = Math.ceil((lockoutUntil - Date.now()) / 1000 / 60);
            return {
                success: false,
                error: `Account locked. Try again in ${remainingTime} minute(s).`,
                lockedUntil: lockoutUntil
            };
        }

        // Check CAPTCHA requirement
        if (showCaptcha && !captchaValue) {
            return {
                success: false,
                error: 'Please complete the CAPTCHA verification.',
                requiresCaptcha: true
            };
        }

        // Simulate CAPTCHA validation (in real app, verify on backend)
        if (showCaptcha && captchaValue !== '1234') {
            return {
                success: false,
                error: 'Invalid CAPTCHA. Please try again.',
                requiresCaptcha: true
            };
        }

        // First check static dummy users
        let foundUser = findUserByCredentials(email, password);

        // If not found, check the dynamic "living database" in localStorage
        if (!foundUser) {
            const storedStaff = JSON.parse(localStorage.getItem('ev_staff') || '[]');
            foundUser = (storedStaff as any[]).find(s => s.email === email && s.password === password);
        }

        const ip = getClientIP();
        const device = getDeviceInfo();

        if (foundUser) {
            // Check if user has clinics
            if (!foundUser.clinics || foundUser.clinics.length === 0) {
                addAuditLog({
                    timestamp: new Date().toISOString(),
                    email,
                    success: false,
                    ip,
                    device,
                    reason: 'No clinic assigned'
                });

                return {
                    success: false,
                    error: 'No clinic assigned. Please contact Super Admin.'
                };
            }

            // Successful login
            setUser(foundUser);
            setIsAuthenticated(true);
            setFailedAttempts(0);
            setShowCaptcha(false);
            localStorage.setItem('ev_user', JSON.stringify(foundUser));
            localStorage.removeItem('ev_attempts');
            localStorage.removeItem('ev_lockout');

            // Auto-select clinic if only one
            if (foundUser.clinics.length === 1) {
                const clinics = getClinicsByIds(foundUser.clinics);
                if (clinics.length > 0) {
                    setSelectedClinic(clinics[0]);
                    localStorage.setItem('ev_clinic', JSON.stringify(clinics[0]));
                }
            }

            addAuditLog({
                timestamp: new Date().toISOString(),
                email,
                success: true,
                ip,
                device,
                roles: foundUser.roles,
                selectedClinic: foundUser.clinics.length === 1 ? getClinicsByIds(foundUser.clinics)[0]?.name : 'Pending selection'
            });

            return { success: true, user: foundUser };
        }

        // Failed login
        const newAttempts = failedAttempts + 1;
        setFailedAttempts(newAttempts);
        localStorage.setItem('ev_attempts', newAttempts.toString());

        // Show CAPTCHA after 3 failed attempts
        if (newAttempts >= 3) {
            setShowCaptcha(true);
        }

        // Lock account after 5 failed attempts
        if (newAttempts >= 5) {
            const lockTime = Date.now() + (15 * 60 * 1000); // 15 minutes
            setLockoutUntil(lockTime);
            localStorage.setItem('ev_lockout', lockTime.toString());

            addAuditLog({
                timestamp: new Date().toISOString(),
                email,
                success: false,
                ip,
                device,
                reason: 'Account locked after 5 failed attempts'
            });

            return {
                success: false,
                error: 'Account locked due to multiple failed attempts. Try again in 15 minutes.',
                lockedUntil: lockTime
            };
        }

        addAuditLog({
            timestamp: new Date().toISOString(),
            email,
            success: false,
            ip,
            device,
            reason: 'Invalid credentials'
        });

        return {
            success: false,
            error: `Invalid credentials. ${5 - newAttempts} attempt(s) remaining.`,
            requiresCaptcha: newAttempts >= 3
        };
    };

    const selectClinic = (clinic: any) => {
        setSelectedClinic(clinic);
        localStorage.setItem('ev_clinic', JSON.stringify(clinic));

        // Update audit log with selected clinic
        if (user) {
            addAuditLog({
                timestamp: new Date().toISOString(),
                email: user.email,
                success: true,
                ip: getClientIP(),
                device: getDeviceInfo(),
                roles: user.roles,
                selectedClinic: clinic.name
            });
        }
    };

    const logout = () => {
        if (user) {
            addAuditLog({
                timestamp: new Date().toISOString(),
                email: user.email,
                success: true,
                ip: getClientIP(),
                device: getDeviceInfo(),
                reason: 'User logout'
            });
        }

        setUser(null);
        setSelectedClinic(null);
        setIsAuthenticated(false);
        localStorage.removeItem('ev_user');
        localStorage.removeItem('ev_clinic');
    };

    const getUserClinics = () => {
        if (!user || !user.clinics) return [];
        return getClinicsByIds(user.clinics);
    };

    const resetFailedAttempts = () => {
        setFailedAttempts(0);
        setShowCaptcha(false);
        setLockoutUntil(null);
        localStorage.removeItem('ev_attempts');
        localStorage.removeItem('ev_lockout');
    };

    const getAuditLogs = () => {
        return auditLogs;
    };

    const value = {
        user,
        selectedClinic,
        isAuthenticated,
        loading,
        failedAttempts,
        lockoutUntil,
        showCaptcha,
        login,
        logout,
        selectClinic,
        getUserClinics,
        resetFailedAttempts,
        getAuditLogs
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within AuthProvider');
    }
    return context;
};
