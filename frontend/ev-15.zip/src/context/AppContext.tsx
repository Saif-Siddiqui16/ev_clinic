import React, { createContext, useContext, useState, useEffect } from 'react';
import { dummyClinics } from '../data/clinics';
import { dummyUsers } from '../data/users';
import { dummyPatients } from '../data/patients';

interface AppContextType {
    clinics: any[];
    staff: any[];
    patients: any[];
    bookings: any[];
    invoices: any[];
    formTemplates: any[];
    auditLogs: any[];
    addClinic: (clinic: any) => any;
    updateClinic: (clinicId: number, updates: any) => void;
    toggleClinicStatus: (clinicId: number) => void;
    deleteClinic: (clinicId: number) => void;
    updateClinicModules: (clinicId: number, modules: any) => void;
    addStaff: (member: any, clinicId?: number) => any;
    toggleStaffStatus: (staffId: number) => void;
    deleteStaff: (staffId: number) => void;
    addPatient: (patient: any) => any;
    updatePatientStatus: (patientId: number, status: string) => void;
    addBooking: (booking: any) => any;
    approveBooking: (bookingId: number) => void;
    rejectBooking: (bookingId: number) => void;
    addInvoice: (invoice: any) => any;
    addFormTemplate: (template: any) => any;
    deleteFormTemplate: (templateId: number) => void;
    updateBookingStatus: (bookingId: number, status: string) => void;
    addAssessment: (patientId: number, assessment: any) => void;
    addDepartmentNotification: (clinicId: number, department: string, message: any) => void;
    logAction: (action: string, performedBy: string, details: any) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider = ({ children }: { children: React.ReactNode }) => {
    // Persistent State (Simulating Database)
    const [clinics, setClinics] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_clinics');
        return saved ? JSON.parse(saved) : dummyClinics;
    });

    const [staff, setStaff] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_staff');
        return saved ? JSON.parse(saved) : dummyUsers.filter(u => !u.roles.includes('super_admin')).map((u: any) => ({
            ...u,
            status: u.status || 'active',
            joined: u.joined || '2023-01-01'
        }));
    });

    const [patients, setPatients] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_patients');
        return saved ? JSON.parse(saved) : dummyPatients;
    });

    const [bookings, setBookings] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_bookings');
        if (saved) return JSON.parse(saved);

        // Initial dummy bookings
        return [
            { id: 1, patientId: 1, doctorId: 5, clinicId: 1, time: '10:30 AM', date: new Date().toISOString().split('T')[0], status: 'Checked In', source: 'Online' },
            { id: 2, patientId: 2, doctorId: 5, clinicId: 1, time: '11:15 AM', date: new Date().toISOString().split('T')[0], status: 'Pending', source: 'Call' }
        ];
    });

    const [auditLogs, setAuditLogs] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_audit_logs');
        return saved ? JSON.parse(saved) : [];
    });

    // Save to LocalStorage on changes
    useEffect(() => localStorage.setItem('ev_clinics', JSON.stringify(clinics)), [clinics]);
    useEffect(() => localStorage.setItem('ev_staff', JSON.stringify(staff)), [staff]);
    useEffect(() => localStorage.setItem('ev_patients', JSON.stringify(patients)), [patients]);
    useEffect(() => localStorage.setItem('ev_bookings', JSON.stringify(bookings)), [bookings]);
    useEffect(() => localStorage.setItem('ev_audit_logs', JSON.stringify(auditLogs)), [auditLogs]);

    // --- ACTIONS ---

    // Audit Logging
    const logAction = (action: string, performedBy: string, details: any) => {
        const log = {
            id: Date.now(),
            action,
            performedBy,
            timestamp: new Date().toISOString(),
            ipAddress: '192.168.1.1',
            details
        };
        setAuditLogs(prev => [log, ...prev]);
    };

    // Clinic Actions
    const addClinic = (clinic: any) => {
        const newClinic = {
            ...clinic,
            id: Date.now(),
            status: 'active',
            createdDate: new Date().toISOString(),
            modules: { pharmacy: true, radiology: false, laboratory: false, billing: true }
        };
        setClinics(prev => [...prev, newClinic]);
        logAction('Clinic Created', 'Super Admin', { clinicName: clinic.name, clinicId: newClinic.id });
        return newClinic;
    };

    const updateClinic = (clinicId: number, updates: any) => {
        setClinics(prev => prev.map(c => c.id === clinicId ? { ...c, ...updates } : c));
        logAction('Clinic Updated', 'Super Admin', { clinicId, updates });
    };

    const toggleClinicStatus = (clinicId: number) => {
        const clinic = clinics.find(c => c.id === clinicId);
        const newStatus = clinic?.status === 'active' ? 'inactive' : 'active';
        setClinics(prev => prev.map(c => c.id === clinicId ? { ...c, status: newStatus } : c));
        logAction('Clinic Status Changed', 'Super Admin', { clinicId, newStatus });
    };

    const deleteClinic = (clinicId: number) => {
        const clinic = clinics.find(c => c.id === clinicId);
        setClinics(prev => prev.filter(c => c.id !== clinicId));
        logAction('Clinic Deleted', 'Super Admin', { clinicId, clinicName: clinic?.name });
    };

    const updateClinicModules = (clinicId: number, modules: any) => {
        setClinics(prev => prev.map(c => c.id === clinicId ? { ...c, modules } : c));
        logAction('Modules Updated', 'Super Admin', { clinicId, modules });
    };

    // Staff Actions
    const addStaff = (member: any, clinicId?: number) => {
        const newMember = {
            ...member,
            id: Date.now(),
            status: 'active',
            clinicId: clinicId || member.clinicId,
            roles: member.roles || [member.role],
            createdDate: new Date().toISOString()
        };
        setStaff(prev => [...prev, newMember]);
        logAction('Staff Member Created', 'Super Admin', { adminName: member.name, clinicId, roles: newMember.roles });
        return newMember;
    };

    const toggleStaffStatus = (staffId: number) => {
        const member = staff.find(s => s.id === staffId);
        const newStatus = member?.status === 'active' ? 'inactive' : 'active';
        setStaff(prev => prev.map(s => s.id === staffId ? { ...s, status: newStatus } : s));
        logAction('Staff Status Changed', 'Super Admin', { staffId, newStatus });
    };

    const deleteStaff = (staffId: number) => {
        const member = staff.find(s => s.id === staffId);
        setStaff(prev => prev.filter(s => s.id !== staffId));
        logAction('Staff Deleted', 'Super Admin', { staffId, staffName: member?.name });
    };

    // Patient Actions
    const addPatient = (patient: any) => {
        const newPatient = { ...patient, id: Date.now(), history: [] };
        setPatients(prev => [...prev, newPatient]);
        return newPatient;
    };

    // Booking Actions
    const addBooking = (booking: any) => {
        const newBooking = { ...booking, id: Date.now(), status: 'Pending' };
        setBookings(prev => [...prev, newBooking]);

        // Notify Admission department
        addDepartmentNotification(booking.clinicId || 1, 'admission', {
            patientName: booking.patientName,
            bookingId: newBooking.id,
            message: `New appointment request from ${booking.patientName}`
        });

        logAction('New Booking Request', 'Public', { patientName: booking.patientName, bookingId: newBooking.id });
        return newBooking;
    };

    const updateBookingStatus = (bookingId: number, status: string) => {
        setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status } : b));
        logAction('Booking Status Updated', 'Reception', { bookingId, status });
    };

    const approveBooking = (bookingId: number) => {
        const booking = bookings.find(b => b.id === bookingId);
        if (booking) {
            let patientIdToLink = booking.patientId;
            let statusToUpdate = 'Approved';

            // Auto-create patient record if not exists
            const existingPatient = patients.find(p => p.email === booking.email || p.phone === booking.phone);

            if (existingPatient) {
                patientIdToLink = existingPatient.id;
            } else {
                const newId = Date.now();
                const newPatient = {
                    id: newId,
                    name: booking.patientName,
                    email: booking.email,
                    phone: booking.phone,
                    status: 'Active',
                    createdYear: new Date().getFullYear(),
                    history: [],
                    assessments: [],
                    lastVisit: new Date().toISOString().split('T')[0]
                };
                setPatients(prev => [...prev, newPatient]);
                patientIdToLink = newId;
                logAction('Patient Auto-Created', 'System', { patientName: newPatient.name, bookingId });
            }

            // Update booking status AND link to correct patient ID
            setBookings(prev => prev.map(b =>
                b.id === bookingId
                    ? { ...b, status: statusToUpdate, patientId: patientIdToLink }
                    : b
            ));
            logAction('Booking Status Updated', 'Reception', { bookingId, status: statusToUpdate, linkedPatientId: patientIdToLink });
        }
    };

    const rejectBooking = (bookingId: number) => {
        updateBookingStatus(bookingId, 'Cancelled');
    };

    const addAssessment = (patientId: number, assessment: any) => {
        setPatients(prev => prev.map(p => {
            if (p.id === patientId) {
                const updatedAssessments = [...(p.assessments || []), { ...assessment, id: Date.now(), date: new Date().toISOString() }];
                return { ...p, assessments: updatedAssessments, lastVisit: new Date().toISOString().split('T')[0] };
            }
            return p;
        }));
        logAction('Assessment Added', 'Doctor', { patientId });
    };

    const [notifications, setNotifications] = useState<any[]>([]);
    const addDepartmentNotification = (clinicId: number, department: string, message: any) => {
        const newNotification = { id: Date.now(), clinicId, department, message, status: 'unread', timestamp: new Date().toISOString() };
        setNotifications(prev => [newNotification, ...prev]);
        logAction('Department Notification', 'Doctor', { department, clinicId });
    };

    // Invoice Actions
    const [invoices, setInvoices] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_invoices');
        return saved ? JSON.parse(saved) : [
            { id: 'INV-9021', patientId: 1, clinicId: 1, service: 'Consultation', amount: 350, status: 'Paid', date: '2024-01-10' },
            { id: 'INV-9022', patientId: 2, clinicId: 1, service: 'Lab Test', amount: 1200, status: 'Pending', date: '2024-01-11' }
        ];
    });

    useEffect(() => localStorage.setItem('ev_invoices', JSON.stringify(invoices)), [invoices]);

    const addInvoice = (invoice: any) => {
        const newInvoice = {
            ...invoice,
            id: `INV-${Math.floor(1000 + Math.random() * 9000)}`,
            date: new Date().toISOString().split('T')[0]
        };
        setInvoices(prev => [newInvoice, ...prev]);
        logAction('Invoice Created', 'Reception', { invoiceId: newInvoice.id, amount: newInvoice.amount });
        return newInvoice;
    };

    // Assessment Forms (Dynamic)
    // Assessment Forms (Dynamic)
    const [formTemplates, setFormTemplates] = useState<any[]>(() => {
        const defaultTemplates = [
            {
                id: 1,
                name: 'General Patient Assessment',
                specialty: 'General',
                status: 'published',
                version: 1,
                fields: [
                    { id: 'chief_complaint', type: 'text', label: 'Chief Complaint', required: true, placeholder: 'Main reason for visit' },
                    { id: 'history', type: 'textarea', label: 'Medical History', required: false, placeholder: 'Previous conditions & allergies' },
                    { id: 'vitals_temp', type: 'text', label: 'Temperature (°C)', required: true, placeholder: '37.0' },
                    { id: 'vitals_bp', type: 'text', label: 'Blood Pressure', required: true, placeholder: '120/80' },
                    { id: 'diagnosis', type: 'textarea', label: 'Diagnosis', required: true, placeholder: 'Clinical diagnosis' }
                ]
            },
            {
                id: 2,
                name: 'Follow-up Visit',
                specialty: 'General',
                status: 'published',
                version: 1,
                fields: [
                    { id: 'progress', type: 'textarea', label: 'Progress Note', required: true, placeholder: 'Patient progress since last visit' },
                    { id: 'symptoms_change', type: 'dropdown', label: 'Symptoms Status', required: true, options: ['Improved', 'Unchanged', 'Worsened'] },
                    { id: 'next_plan', type: 'textarea', label: 'Next Steps', required: true, placeholder: 'Plan regarding medication/therapy' }
                ]
            },
            {
                id: 3,
                name: 'Cardiac Assessment',
                specialty: 'Cardiology',
                status: 'published',
                version: 1,
                fields: [
                    { id: 'chest_pain', type: 'dropdown', label: 'Chest Pain?', required: true, options: ['None', 'Mild', 'Severe', 'Radiating'] },
                    { id: 'ecg_notes', type: 'textarea', label: 'ECG Findings', required: false, placeholder: 'Sinus rhythm details...' },
                    { id: 'bp_monitor', type: 'text', label: 'Current BP', required: true, placeholder: 'mmHg' }
                ]
            }
        ];

        const saved = localStorage.getItem('ev_form_templates');
        if (!saved) return defaultTemplates;

        try {
            const parsed = JSON.parse(saved);
            // Check if our defaults are missing (by name)
            const missingDefaults = defaultTemplates.filter(dt => !parsed.some((p: any) => p.name === dt.name));
            return [...parsed, ...missingDefaults];
        } catch (e) {
            return defaultTemplates;
        }
    });

    useEffect(() => localStorage.setItem('ev_form_templates', JSON.stringify(formTemplates)), [formTemplates]);

    const addFormTemplate = (template: any) => {
        const newTemplate = { ...template, id: Date.now() };
        setFormTemplates(prev => [...prev, newTemplate]);
        return newTemplate;
    };

    const deleteFormTemplate = (templateId: number) => {
        setFormTemplates(prev => prev.filter(t => t.id !== templateId));
    };

    const updatePatientStatus = (patientId: number, status: string) => {
        setPatients(prev => prev.map(p => p.id === patientId ? { ...p, status } : p));
        logAction('Patient Status Updated', 'Reception', { patientId, status });
    };

    const value = {
        clinics,
        staff,
        patients,
        bookings,
        invoices,
        formTemplates,
        auditLogs,
        addClinic,
        updateClinic,
        toggleClinicStatus,
        deleteClinic,
        updateClinicModules,
        addStaff,
        toggleStaffStatus,
        deleteStaff,
        addPatient,
        updatePatientStatus,
        addBooking,
        approveBooking,
        rejectBooking,
        updateBookingStatus,
        addInvoice,
        addFormTemplate,
        deleteFormTemplate,
        addAssessment,
        addDepartmentNotification,
        notifications,
        logAction
    };

    return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
    const context = useContext(AppContext);
    if (!context) throw new Error('useApp must be used within AppProvider');
    return context;
};
