import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { FiSearch, FiPlus, FiEye, FiCheckCircle, FiChevronRight, FiFileText, FiPrinter } from 'react-icons/fi';
import { useApp } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import Modal from '../../components/Modal';
import './Dashboard.css';
import './Assessments.css';

const Assessments = () => {
    const { patients, formTemplates, selectedClinic, addAssessment, addDepartmentNotification } = useApp() as any;
    const { user } = useAuth() as any;
    const location = useLocation();
    const [searchTerm, setSearchTerm] = useState('');
    const [isNewAssessmentOpen, setIsNewAssessmentOpen] = useState(false);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [viewingAssessment, setViewingAssessment] = useState<any>(null);
    const [viewMode, setViewMode] = useState<'details' | 'report'>('details');
    const [assessmentStep, setAssessmentStep] = useState(1); // 1: Template selection, 2: Form filling

    // Selection state
    const [selectedPatientId, setSelectedPatientId] = useState('');
    const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
    const [formData, setFormData] = useState<Record<string, any>>({});

    // Filter templates for this clinic
    const clinicTemplates = formTemplates.filter((t: any) => t.clinicId === selectedClinic?.id || !t.clinicId);

    // Mock assessments data (stored in local storage)
    const [assessments, setAssessments] = useState<any[]>(() => {
        const saved = localStorage.getItem('ev_assessments');
        if (saved) return JSON.parse(saved);

        // Initial sample assessment for demonstration
        return [
            {
                id: 101,
                patientId: 1,
                patientName: 'John Doe',
                templateId: 1,
                templateName: 'General Patient Assessment',
                date: '2024-01-15T10:00:00.000Z',
                data: {
                    '1': 'Persistent migraine for 3 days',
                    '2': 'No major history, allergic to penicillin',
                    '3': '7',
                    'pharmacyOrder': 'Paracetamol 500mg (2x daily), Migra-Aid pill',
                    'labOrder': 'Complete Blood Count (CBC)'
                },
                status: 'Completed',
                isClosed: true,
                doctorId: 5,
                clinicId: 1
            }
        ];
    });

    useEffect(() => localStorage.setItem('ev_assessments', JSON.stringify(assessments)), [assessments]);

    // Handle initial search or new assessment from navigation state
    useEffect(() => {
        if (location.state?.search) {
            setSearchTerm(location.state.search);
        }

        if (location.state?.openNew) {
            setIsNewAssessmentOpen(true);
            if (location.state.patientId) {
                setSelectedPatientId(String(location.state.patientId));
            }
        }
    }, [location.state]);

    const handleStartAssessment = (template: any) => {
        setSelectedTemplate(template);
        setAssessmentStep(2);
        // Initialize form data
        const initialData: Record<string, any> = {};
        template.fields.forEach((f: any) => {
            initialData[f.id] = '';
        });
        setFormData(initialData);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const patient = (patients as any[]).find(p => p.id === Number(selectedPatientId));

        const assessmentId = Date.now();
        const newAssessment = {
            id: assessmentId,
            patientId: Number(selectedPatientId),
            patientName: patient?.name || 'Unknown',
            templateId: selectedTemplate.id,
            templateName: selectedTemplate.name,
            date: new Date().toISOString(),
            data: formData,
            status: 'Completed',
            isClosed: true,
            doctorId: user.id,
            clinicId: selectedClinic?.id
        };

        // Trigger notifications if orders exist in formData
        if (formData.pharmacyOrder) {
            addDepartmentNotification(selectedClinic?.id, 'pharmacy', { patientId: selectedPatientId, details: formData.pharmacyOrder });
        }
        if (formData.labOrder) {
            addDepartmentNotification(selectedClinic?.id, 'laboratory', { patientId: selectedPatientId, details: formData.labOrder });
        }
        if (formData.radiologyOrder) {
            addDepartmentNotification(selectedClinic?.id, 'radiology', { patientId: selectedPatientId, details: formData.radiologyOrder });
        }

        addAssessment(Number(selectedPatientId), newAssessment);

        // Update local assessments list (if used for display)
        setAssessments([newAssessment, ...assessments]);

        setIsNewAssessmentOpen(false);
        resetForm();
    };

    const resetForm = () => {
        setAssessmentStep(1);
        setSelectedPatientId('');
        setSelectedTemplate(null);
        setFormData({});
    };

    const filteredAssessments = assessments.filter(assessment =>
        assessment.patientName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="doctor-dashboard">
            <div className="assessments-header">
                <div>
                    <h1 className="assessments-title">Assessments</h1>
                    <p className="assessments-subtitle">Create and manage patient assessments</p>
                </div>
                <button className="btn btn-primary btn-with-icon" onClick={() => setIsNewAssessmentOpen(true)}>
                    <FiPlus />
                    <span>New Assessment</span>
                </button>
            </div>

            <div className="assessments-search-card">
                <div className="search-stats-row">
                    <div className="search-box-left">
                        <FiSearch className="search-icon-small" />
                        <input
                            type="text"
                            placeholder="Search by patient name..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="search-input-minimal"
                        />
                    </div>
                </div>
            </div>

            <div className="assessments-grid">
                {filteredAssessments.length > 0 ? (
                    filteredAssessments.map(assessment => (
                        <div key={assessment.id} className="assessment-card">
                            <div className="assessment-header-row">
                                <div className="assessment-patient-info">
                                    <h3 className="assessment-patient-name">{assessment.patientName}</h3>
                                    <p className="assessment-date">
                                        {new Date(assessment.date).toLocaleString()} • {assessment.templateName}
                                    </p>
                                </div>
                                <span className="status-badge completed">
                                    <FiCheckCircle size={14} />
                                    {assessment.status}
                                </span>
                            </div>

                            {/* Short preview of key findings */}
                            <div className="assessment-preview-content">
                                {Object.entries(assessment.data || {})
                                    .filter(([key]) => !['pharmacyOrder', 'labOrder', 'radiologyOrder'].includes(key))
                                    .slice(0, 2)
                                    .map(([key, value]: [string, any]) => {
                                        const template = formTemplates.find((t: any) => t.id === assessment.templateId);
                                        const field = template?.fields?.find((f: any) => f.id === key);
                                        return (
                                            <div key={key} className="preview-item">
                                                <span className="preview-label">{field?.label || key}:</span>
                                                <span className="preview-val">{value}</span>
                                            </div>
                                        );
                                    })}
                            </div>
                            <div className="assessment-actions">
                                <button className="action-btn-icon" onClick={() => { setViewingAssessment(assessment); setViewMode('details'); setIsViewModalOpen(true); }} title="Quick View">
                                    <FiEye />
                                </button>
                                <button className="action-btn-icon" onClick={() => { setViewingAssessment(assessment); setViewMode('report'); setIsViewModalOpen(true); }} title="Medical Report">
                                    <FiFileText />
                                </button>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="empty-state-assessments">
                        <div className="empty-icon-large">
                            <FiCheckCircle />
                        </div>
                        <h3>No assessments found</h3>
                    </div>
                )}
            </div>

            <Modal
                isOpen={isNewAssessmentOpen}
                onClose={() => { setIsNewAssessmentOpen(false); resetForm(); }}
                title="New Clinical Assessment"
                size="lg"
            >
                {assessmentStep === 1 ? (
                    <div className="assessment-init">
                        <div className="form-group mb-lg">
                            <label>1. Select Patient *</label>
                            <select
                                required
                                value={selectedPatientId}
                                onChange={e => setSelectedPatientId(e.target.value)}
                            >
                                <option value="">Choose patient...</option>
                                {(patients as any[]).map((p: any) => (
                                    <option key={p.id} value={p.id}>{p.name} (P-{p.id})</option>
                                ))}
                            </select>
                        </div>

                        <label>2. Choose Assessment Template *</label>
                        <div className="templates-selection-grid mt-sm">
                            {clinicTemplates.length > 0 ? (
                                clinicTemplates.map((template: any) => (
                                    <button
                                        key={template.id}
                                        type="button"
                                        className="template-select-card"
                                        onClick={() => handleStartAssessment(template)}
                                        disabled={!selectedPatientId}
                                    >
                                        <div className="template-icon"><FiFileText /></div>
                                        <div className="template-info">
                                            <h4>{template.name}</h4>
                                            <p>{template.fields.length} points of assessment</p>
                                        </div>
                                        <FiChevronRight className="arrow" />
                                    </button>
                                ))
                            ) : (
                                <div className="no-templates-message">
                                    <p>No assessment templates found for this clinic.</p>
                                    <small>Contact your clinic administrator to add templates.</small>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <form className="dynamic-assessment-form" onSubmit={handleSubmit}>
                        <div className="form-header-minimal">
                            <h3>{selectedTemplate.name}</h3>
                            <p>Patient: <strong>{(patients as any[]).find(p => p.id === Number(selectedPatientId))?.name}</strong></p>
                        </div>

                        <div className="dynamic-fields-scroll mt-lg">
                            {selectedTemplate.fields.map((field: any) => (
                                <div key={field.id} className="form-group">
                                    <label>
                                        {field.label} {field.required && <span className="text-danger">*</span>}
                                    </label>
                                    {field.type === 'text' && (
                                        <input
                                            type="text"
                                            required={field.required}
                                            placeholder={field.placeholder}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        />
                                    )}
                                    {field.type === 'textarea' && (
                                        <textarea
                                            rows={3}
                                            required={field.required}
                                            placeholder={field.placeholder}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        ></textarea>
                                    )}
                                    {field.type === 'number' && (
                                        <input
                                            type="number"
                                            required={field.required}
                                            placeholder={field.placeholder}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        />
                                    )}
                                    {field.type === 'dropdown' && (
                                        <select
                                            required={field.required}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        >
                                            <option value="">Select...</option>
                                            {field.options?.map((opt: string) => (
                                                <option key={opt} value={opt}>{opt}</option>
                                            ))}
                                        </select>
                                    )}
                                    {field.type === 'date' && (
                                        <input
                                            type="date"
                                            required={field.required}
                                            value={formData[field.id]}
                                            onChange={e => setFormData({ ...formData, [field.id]: e.target.value })}
                                        />
                                    )}
                                </div>
                            ))}

                            <h4 className="form-section-title mt-lg">Prescriptions & Orders</h4>
                            <div className="form-group">
                                <label>Pharmacy (Medicines)</label>
                                <textarea
                                    placeholder="List medicines, dosage, and frequency..."
                                    value={formData.pharmacyOrder || ''}
                                    onChange={e => setFormData({ ...formData, pharmacyOrder: e.target.value })}
                                ></textarea>
                            </div>
                            <div className="form-grid grid-2">
                                <div className="form-group">
                                    <label>Laboratory (Tests)</label>
                                    <textarea
                                        placeholder="Specific lab tests required..."
                                        value={formData.labOrder || ''}
                                        onChange={e => setFormData({ ...formData, labOrder: e.target.value })}
                                    ></textarea>
                                </div>
                                <div className="form-group">
                                    <label>Radiology (Scans)</label>
                                    <textarea
                                        placeholder="X-Ray, MRI, CT Scan details..."
                                        value={formData.radiologyOrder || ''}
                                        onChange={e => setFormData({ ...formData, radiologyOrder: e.target.value })}
                                    ></textarea>
                                </div>
                            </div>
                        </div>

                        <div className="modal-actions mt-xl">
                            <button type="button" className="btn btn-secondary" onClick={() => setAssessmentStep(1)}>Back</button>
                            <button type="submit" className="btn btn-primary">
                                <FiCheckCircle className="mr-xs" /> Complete Assessment
                            </button>
                        </div>
                    </form>
                )}
            </Modal>

            {/* View/Report Modal */}
            <Modal
                isOpen={isViewModalOpen}
                onClose={() => setIsViewModalOpen(false)}
                title={viewMode === 'details' ? "Quick Assessment View" : "Medical Assessment Report"}
                size="lg"
            >
                {viewingAssessment && (
                    <div className={`assessment-display-container ${viewMode}`}>
                        {/* Branded Header (Visible in Report Mode and Print) */}
                        <div className={`report-branded-header ${viewMode === 'report' ? 'show-on-screen' : ''}`}>
                            <div className="clinic-brand">
                                <div className="brand-logo-small">EV</div>
                                <div className="brand-info">
                                    <h2>{selectedClinic?.name || 'EV CLINIC'}</h2>
                                    <p>Comprehensive Healthcare Solutions</p>
                                </div>
                            </div>
                            <div className="report-meta">
                                <p><strong>Report ID:</strong> {viewingAssessment.id}</p>
                                <p><strong>Date:</strong> {new Date(viewingAssessment.date).toLocaleDateString()}</p>
                            </div>
                        </div>

                        <div className="patient-banner-brief">
                            <div className="patient-meta-core">
                                <h1>{viewingAssessment.patientName}</h1>
                                <span>P-{viewingAssessment.patientId} • {viewingAssessment.templateName}</span>
                            </div>
                            <div className={`status-pill-minimal ${viewingAssessment.status.toLowerCase()}`}>
                                {viewingAssessment.status}
                            </div>
                        </div>

                        <div className="content-layout-refined mt-lg">
                            <div className="clinical-observations">
                                <h3 className="section-title-minimal">Clinical Observations</h3>
                                <div className="observations-grid">
                                    {Object.entries(viewingAssessment.data || {}).map(([key, value]: [string, any]) => {
                                        if (['pharmacyOrder', 'labOrder', 'radiologyOrder'].includes(key)) return null;

                                        const template = formTemplates.find((t: any) => t.id === viewingAssessment.templateId);
                                        const field = template?.fields?.find((f: any) => f.id === key);
                                        const label = field?.label || key;

                                        return (
                                            <div key={key} className="obs-item">
                                                <label>{label}</label>
                                                <div className="obs-value">{value || 'N/A'}</div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>

                            {(viewingAssessment.data?.pharmacyOrder || viewingAssessment.data?.labOrder || viewingAssessment.data?.radiologyOrder) && (
                                <div className="medical-orders-box mt-xl">
                                    <h3 className="section-title-minimal">Plans & Orders</h3>
                                    <div className="orders-refined-list">
                                        {viewingAssessment.data?.pharmacyOrder && (
                                            <div className="order-entry">
                                                <div className="order-type">Prescription</div>
                                                <div className="order-details-text">{viewingAssessment.data.pharmacyOrder}</div>
                                            </div>
                                        )}
                                        {viewingAssessment.data?.labOrder && (
                                            <div className="order-entry">
                                                <div className="order-type">Laboratory</div>
                                                <div className="order-details-text">{viewingAssessment.data.labOrder}</div>
                                            </div>
                                        )}
                                        {viewingAssessment.data?.radiologyOrder && (
                                            <div className="order-entry">
                                                <div className="order-type">Radiology</div>
                                                <div className="order-details-text">{viewingAssessment.data.radiologyOrder}</div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>

                        {viewMode === 'report' && (
                            <div className="report-signatures mt-2xl">
                                <div className="sig-block">
                                    <div className="sig-line"></div>
                                    <span>Patient Acknowledgement</span>
                                </div>
                                <div className="sig-block">
                                    <div className="sig-line"></div>
                                    <span>Attending Physician</span>
                                    <strong>Dr. {user?.name}</strong>
                                </div>
                            </div>
                        )}

                        <div className="modal-actions-floating-bottom no-print">
                            <button className="btn btn-secondary" onClick={() => setIsViewModalOpen(false)}>Close</button>
                            <button className="btn btn-primary btn-with-icon" onClick={() => window.print()}>
                                <FiPrinter /> <span>Print Report</span>
                            </button>
                        </div>
                    </div>
                )}
            </Modal>
        </div>
    );
};

export default Assessments;
