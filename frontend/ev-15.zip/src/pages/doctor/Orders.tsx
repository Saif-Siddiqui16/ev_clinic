import { useState } from 'react';
import { FiSearch, FiPlus, FiEye } from 'react-icons/fi';
import { useApp } from '../../context/AppContext';
import Modal from '../../components/Modal';
import './Dashboard.css';
import './Orders.css';

const Orders = () => {
    const { patients } = useApp() as any;
    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState('all');
    const [isNewOrderOpen, setIsNewOrderOpen] = useState(false);

    // Mock orders data
    const mockOrders = [
        {
            id: 1,
            patientName: 'John Doe',
            patientId: 1,
            orderNumber: 'Order #1',
            date: '2024-01-10',
            type: 'Lab',
            tests: 'CBC, Blood Sugar',
            priority: 'Routine',
            status: 'Pending'
        }
    ];

    const tabs = [
        { id: 'all', label: 'All Orders', count: mockOrders.length },
        { id: 'lab', label: 'Laboratory', count: 1 },
        { id: 'radiology', label: 'Radiology', count: 0 },
        { id: 'prescriptions', label: 'Prescriptions', count: 0 }
    ];

    const filteredOrders = mockOrders.filter(order =>
        order.patientName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="doctor-dashboard">
            {/* Page Header */}
            <div className="orders-page-header">
                <div>
                    <h1 className="orders-title">Medical Orders</h1>
                    <p className="orders-subtitle">Manage lab tests, radiology scans, and prescriptions</p>
                </div>
                <button className="btn btn-primary btn-with-icon" onClick={() => setIsNewOrderOpen(true)}>
                    <FiPlus />
                    <span>New Order</span>
                </button>
            </div>

            {/* Search and Filter Card */}
            <div className="orders-filter-card">
                <div className="search-box-full">
                    <FiSearch className="search-icon-small" />
                    <input
                        type="text"
                        placeholder="Search by patient name..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="search-input-minimal"
                    />
                </div>

                <div className="filter-tabs">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            className={`filter-tab ${activeTab === tab.id ? 'active' : ''}`}
                            onClick={() => setActiveTab(tab.id)}
                        >
                            {tab.label} ({tab.count})
                        </button>
                    ))}
                </div>
            </div>

            {/* Orders Grid */}
            <div className="orders-grid">
                {filteredOrders.length > 0 ? (
                    filteredOrders.map(order => (
                        <div key={order.id} className="order-card-modern">
                            <div className="order-card-header">
                                <div className="order-patient-section">
                                    <h3 className="order-patient-name">{order.patientName}</h3>
                                    <p className="order-meta">{order.orderNumber} • {order.date}</p>
                                </div>
                                <span className="order-type-badge lab">
                                    {order.type}
                                </span>
                            </div>

                            <div className="order-details-section">
                                <div className="order-detail-row">
                                    <span className="order-label">Tests/Items:</span>
                                    <span className="order-value">{order.tests}</span>
                                </div>
                                <div className="order-detail-row">
                                    <span className="order-label">Priority:</span>
                                    <span className="order-value">{order.priority}</span>
                                </div>
                            </div>

                            <div className="order-card-footer">
                                <span className={`status-badge-order ${order.status.toLowerCase()}`}>
                                    {order.status}
                                </span>
                                <button className="btn-view-order">
                                    <FiEye />
                                    View
                                </button>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="empty-state-orders">
                        <div className="empty-icon-large">
                            <FiSearch />
                        </div>
                        <h3>No orders found</h3>
                        <p>No orders match your search criteria</p>
                    </div>
                )}
            </div>

            {/* New Order Modal */}
            <Modal
                isOpen={isNewOrderOpen}
                onClose={() => setIsNewOrderOpen(false)}
                title="Create New Order"
                size="lg"
            >
                <form className="order-form-modal" onSubmit={(e) => { e.preventDefault(); setIsNewOrderOpen(false); }}>
                    <div className="form-group">
                        <label>Select Patient *</label>
                        <select required>
                            <option value="">Choose patient...</option>
                            {(patients as any[]).map((patient: any) => (
                                <option key={patient.id} value={patient.id}>
                                    {patient.name} (P-{patient.id})
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Order Type *</label>
                        <select required>
                            <option value="">Select type...</option>
                            <option value="lab">Laboratory Test</option>
                            <option value="radiology">Radiology Scan</option>
                            <option value="prescription">Prescription</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Tests/Items *</label>
                        <textarea rows={3} placeholder="Enter tests or items (e.g., CBC, Blood Sugar)" required></textarea>
                    </div>

                    <div className="form-grid grid-2">
                        <div className="form-group">
                            <label>Priority</label>
                            <select>
                                <option value="routine">Routine</option>
                                <option value="urgent">Urgent</option>
                                <option value="stat">STAT</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Order Date</label>
                            <input type="date" defaultValue={new Date().toISOString().split('T')[0]} />
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Clinical Notes</label>
                        <textarea rows={3} placeholder="Additional instructions or notes..."></textarea>
                    </div>

                    <div className="modal-actions-refined">
                        <button type="button" className="btn-cancel" onClick={() => setIsNewOrderOpen(false)}>
                            Cancel
                        </button>
                        <button type="submit" className="btn-save">
                            <FiPlus />
                            Create Order
                        </button>
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default Orders;
