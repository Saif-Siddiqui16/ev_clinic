import { useState } from 'react';
import { FiDollarSign, FiTrendingUp, FiCalendar, FiFileText } from 'react-icons/fi';
import { useApp } from '../../context/AppContext';
import './Dashboard.css';
import './Revenue.css';

const Revenue = () => {
    const { bookings } = useApp() as any;
    const [viewMode, setViewMode] = useState('daily');
    const [startDate, setStartDate] = useState('2026-01-01');
    const [endDate, setEndDate] = useState('2026-01-13');

    const completedCount = (bookings as any[]).filter(b => b.status === 'Completed').length;
    const totalEarnings = completedCount * 350;

    // Mock data for chart
    const chartData = [
        { date: 'Jan 7', visits: 0 },
        { date: 'Jan 8', visits: 0 },
        { date: 'Jan 9', visits: 0 },
        { date: 'Jan 10', visits: 0 },
        { date: 'Jan 11', visits: 0 },
        { date: 'Jan 12', visits: 0 },
        { date: 'Jan 13', visits: 0 }
    ];

    return (
        <div className="doctor-dashboard">
            {/* Page Header */}
            <div className="revenue-page-header">
                <div>
                    <h1 className="revenue-title">Earnings</h1>
                    <p className="revenue-subtitle">Your earnings and consultation history</p>
                </div>
                <button className="btn-export">
                    <FiFileText />
                    Export Report
                </button>
            </div>

            {/* Stats Cards */}
            <div className="revenue-stats-grid">
                <div className="revenue-stat-card">
                    <div className="stat-icon-revenue dollar">
                        <FiDollarSign />
                    </div>
                    <p className="stat-label-revenue">Total Earnings</p>
                    <h3 className="stat-value-revenue">AED {totalEarnings}</h3>
                </div>
                <div className="revenue-stat-card">
                    <div className="stat-icon-revenue trending">
                        <FiTrendingUp />
                    </div>
                    <p className="stat-label-revenue">This Month</p>
                    <h3 className="stat-value-revenue">AED 0</h3>
                </div>
                <div className="revenue-stat-card">
                    <div className="stat-icon-revenue calendar">
                        <FiCalendar />
                    </div>
                    <p className="stat-label-revenue">Today</p>
                    <h3 className="stat-value-revenue">AED 0</h3>
                </div>
                <div className="revenue-stat-card">
                    <div className="stat-icon-revenue consultations">
                        <FiTrendingUp />
                    </div>
                    <p className="stat-label-revenue">Total Consultations</p>
                    <h3 className="stat-value-revenue">{completedCount}</h3>
                </div>
            </div>

            {/* Filters Section */}
            <div className="revenue-filters-card">
                <h3 className="filters-title">Filters</h3>
                <div className="filters-row">
                    <div className="filter-group">
                        <label>Start Date</label>
                        <input
                            type="date"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                        />
                    </div>
                    <div className="filter-group">
                        <label>End Date</label>
                        <input
                            type="date"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                        />
                    </div>
                    <div className="filter-actions">
                        <button className="btn-reset">Reset</button>
                        <button className="btn-apply">
                            Apply Filters
                        </button>
                    </div>
                </div>
            </div>

            {/* Earnings Trend Chart */}
            <div className="revenue-chart-card">
                <div className="chart-header">
                    <h3>Earnings Trend</h3>
                    <div className="chart-view-toggle">
                        <button
                            className={`toggle-btn ${viewMode === 'daily' ? 'active' : ''}`}
                            onClick={() => setViewMode('daily')}
                        >
                            Daily
                        </button>
                        <button
                            className={`toggle-btn ${viewMode === 'monthly' ? 'active' : ''}`}
                            onClick={() => setViewMode('monthly')}
                        >
                            Monthly
                        </button>
                    </div>
                </div>

                <div className="chart-area">
                    <div className="chart-bars-revenue">
                        {chartData.map((item, index) => (
                            <div key={index} className="chart-bar-item">
                                <div className="bar-wrapper">
                                    <div
                                        className="bar-fill"
                                        style={{ height: `${item.visits * 10 || 5}%` }}
                                    ></div>
                                </div>
                                <div className="bar-label">
                                    <span className="bar-date">{item.date}</span>
                                    <span className="bar-value">{item.visits} visits</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Transaction History */}
            <div className="revenue-transactions-card">
                <h3 className="transactions-title">Transaction History</h3>
                <div className="transactions-empty">
                    <p>0 transactions</p>
                </div>
            </div>
        </div>
    );
};

export default Revenue;
