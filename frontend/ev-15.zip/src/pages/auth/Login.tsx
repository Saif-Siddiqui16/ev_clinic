import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { FiMail, FiLock, FiAlertCircle, FiEye, FiEyeOff, FiShield, FiClock, FiCheck } from 'react-icons/fi';
import './Login.css';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [rememberMe, setRememberMe] = useState(false);
    const [captcha, setCaptcha] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const [lockoutTime, setLockoutTime] = useState<number | null>(null);

    const { login, showCaptcha, lockoutUntil, failedAttempts } = useAuth() as any;
    const navigate = useNavigate();

    // Load remembered email
    useEffect(() => {
        const rememberedEmail = localStorage.getItem('ev_remembered_email');
        if (rememberedEmail) {
            setEmail(rememberedEmail);
            setRememberMe(true);
        }
    }, []);

    // Update lockout countdown
    useEffect(() => {
        if (lockoutUntil && lockoutUntil > Date.now()) {
            setLockoutTime(lockoutUntil);
            const interval = setInterval(() => {
                if (lockoutUntil <= Date.now()) {
                    setLockoutTime(null);
                    clearInterval(interval);
                } else {
                    setLockoutTime(lockoutUntil);
                }
            }, 1000);
            return () => clearInterval(interval);
        }
    }, [lockoutUntil]);

    const getRemainingLockoutTime = () => {
        if (!lockoutTime) return '';
        const remaining = Math.max(0, lockoutTime - Date.now());
        const minutes = Math.floor(remaining / 60000);
        const seconds = Math.floor((remaining % 60000) / 1000);
        return `${minutes}:${seconds.toString().padStart(2, '0')} `;
    };

    const performLogin = (targetEmail: string, targetPassword: string) => {
        setError('');
        setIsLoading(true);

        setTimeout(() => {
            try {
                const result = login(targetEmail, targetPassword, '');

                if (result.success) {
                    const user = result.user;
                    if (!user.roles.includes('super_admin') && user.clinics && user.clinics.length > 1) {
                        navigate('/select-clinic');
                    } else {
                        const primaryRole = user.roles[0];
                        const paths: Record<string, string> = {
                            super_admin: '/super-admin',
                            clinic_admin: '/clinic-admin',
                            admission: '/reception',
                            reception: '/reception',
                            doctor: '/doctor',
                            patient: '/patient'
                        };
                        navigate(paths[primaryRole] || '/');
                    }
                } else {
                    setError(result.error || 'Login failed. Please try again.');
                    setIsLoading(false);
                }
            } catch (err) {
                setError('Unable to connect to service. Try again later.');
                setIsLoading(false);
            }
        }, 800);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        performLogin(email, password);
    };

    const handleQuickLogin = (role: string) => {
        const demoAccounts: Record<string, { email: string; password: string }> = {
            super_admin: { email: 'superadmin@ev.com', password: 'admin123' },
            clinic_admin: { email: 'admin@husri.com', password: 'admin123' },
            admission: { email: 'reception@husri.com', password: 'reception123' },
            doctor: { email: 'doctor@husri.com', password: 'doctor123' },
            patient: { email: 'patient@ev.com', password: 'patient123' }
        };

        const account = demoAccounts[role];
        if (account) {
            setEmail(account.email);
            setPassword(account.password);
            performLogin(account.email, account.password);
        }
    };

    const isLocked = !!(lockoutTime && lockoutTime > Date.now());

    return (
        <div className="login-container">
            <div className="login-layout-wrapper">
                <div className="demo-access-container side-panel">
                    <div className="demo-credentials">
                        <h3 className="demo-title">Express Access</h3>
                        <p className="demo-subtitle">Select a profile for instant login</p>

                        <div className="demo-table-wrapper">
                            <table className="demo-table">
                                <thead>
                                    <tr>
                                        <th>Role Profile</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr onClick={() => handleQuickLogin('super_admin')}>
                                        <td>
                                            <span className="role-name">Super Admin</span>
                                            <span className="role-email">superadmin@ev.com</span>
                                        </td>
                                        <td><button className="btn-table-login">Login</button></td>
                                    </tr>
                                    <tr onClick={() => handleQuickLogin('clinic_admin')}>
                                        <td>
                                            <span className="role-name">Clinic Admin</span>
                                            <span className="role-email">admin@husri.com</span>
                                        </td>
                                        <td><button className="btn-table-login">Login</button></td>
                                    </tr>
                                    <tr onClick={() => handleQuickLogin('admission')}>
                                        <td>
                                            <span className="role-name">Admission</span>
                                            <span className="role-email">reception@husri.com</span>
                                        </td>
                                        <td><button className="btn-table-login">Login</button></td>
                                    </tr>
                                    <tr onClick={() => handleQuickLogin('doctor')}>
                                        <td>
                                            <span className="role-name">Doctor</span>
                                            <span className="role-email">doctor@husri.com</span>
                                        </td>
                                        <td><button className="btn-table-login">Login</button></td>
                                    </tr>
                                    <tr onClick={() => handleQuickLogin('patient')}>
                                        <td>
                                            <span className="role-name">Patient</span>
                                            <span className="role-email">patient@ev.com</span>
                                        </td>
                                        <td><button className="btn-table-login">Login</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div className="demo-passwords">
                            <FiCheck className="pass-icon" />
                            <span>Passwords: <code>admin123</code> / <code>doctor123</code></span>
                        </div>
                    </div>
                </div>

                <div className="login-card">
                    <div className="login-header">
                        <div className="brand-icon-wrapper mb-md">
                            <img src="/sidebar-logo.jpg" alt="Exclusive Vision Logo" className="brand-icon-img-login" />
                        </div>
                        <h1 className="login-title">Exclusive Vision</h1>
                        <h2 className="login-subtitle">Hospital Information System</h2>
                        <p className="login-helper-text">You may be asked to select a clinic after login</p>
                    </div>

                    <form className="login-form" onSubmit={handleSubmit}>
                        {error && (
                            <div className="error-message">
                                <FiAlertCircle size={18} />
                                <span>{error}</span>
                            </div>
                        )}

                        {isLocked && (
                            <div className="lockout-message">
                                <FiClock size={18} />
                                <div>
                                    <strong>Account Locked</strong>
                                    <p>Too many failed attempts. Try again in {getRemainingLockoutTime()}</p>
                                </div>
                            </div>
                        )}

                        {!isLocked && failedAttempts > 0 && failedAttempts < 5 && (
                            <div className="warning-message">
                                <FiShield size={18} />
                                <span>{5 - failedAttempts} attempt(s) remaining before account lock</span>
                            </div>
                        )}

                        <div className="form-group">
                            <label htmlFor="email">Work Email *</label>
                            <div className="input-with-icon">
                                <FiMail className="input-icon" />
                                <input
                                    type="email"
                                    id="email"
                                    placeholder="name@ev.com"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    disabled={isLocked}
                                    required
                                    aria-label="Work Email"
                                />
                            </div>
                        </div>

                        <div className="form-group">
                            <label htmlFor="password">Security Password *</label>
                            <div className="input-with-icon">
                                <FiLock className="input-icon" />
                                <input
                                    type={showPassword ? "text" : "password"}
                                    id="password"
                                    placeholder="••••••••"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    disabled={isLocked}
                                    required
                                    minLength={8}
                                    aria-label="Security Password"
                                />
                                <button
                                    type="button"
                                    className="password-toggle"
                                    onClick={() => setShowPassword(!showPassword)}
                                    tabIndex={-1}
                                    aria-label={showPassword ? "Hide password" : "Show password"}
                                >
                                    {showPassword ? <FiEyeOff /> : <FiEye />}
                                </button>
                            </div>
                            <small className="password-hint">Min. 8 characters</small>
                        </div>

                        {showCaptcha && (
                            <div className="form-group captcha-group">
                                <label htmlFor="captcha">Security Verification *</label>
                                <div className="captcha-box">
                                    <div className="captcha-challenge">
                                        <span className="captcha-text">1234</span>
                                        <small>Enter the code above</small>
                                    </div>
                                    <input
                                        type="text"
                                        id="captcha"
                                        placeholder="Enter code"
                                        value={captcha}
                                        onChange={(e) => setCaptcha(e.target.value)}
                                        disabled={isLocked}
                                        required
                                        maxLength={4}
                                        aria-label="CAPTCHA verification code"
                                    />
                                </div>
                            </div>
                        )}

                        <div className="form-options">
                            <label className="remember-me">
                                <input
                                    type="checkbox"
                                    checked={rememberMe}
                                    onChange={(e) => setRememberMe(e.target.checked)}
                                    disabled={isLocked}
                                />
                                <span>Remember credentials</span>
                            </label>
                            <a href="#" className="forgot-password" onClick={(e) => {
                                e.preventDefault();
                                alert('Password reset flow will be implemented. For demo, use provided credentials.');
                            }}>Security Reset?</a>
                        </div>

                        <button
                            type="submit"
                            className={`btn btn - primary btn - full ${isLoading ? 'loading' : ''} `}
                            disabled={isLoading || isLocked}
                        >
                            {isLoading ? (
                                <div className="spinner-loader"></div>
                            ) : 'Access Dashboard'}
                        </button>
                    </form>

                    <div className="login-footer">
                        <p>Don't have an account? <a href="#" onClick={(e) => {
                            e.preventDefault();
                            alert('Please contact your System Administrator for account creation.');
                        }}>Contact Super Admin</a></p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
