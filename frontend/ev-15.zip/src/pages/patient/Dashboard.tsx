import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { FiCalendar, FiActivity, FiInfo, FiGrid } from 'react-icons/fi';
import { NavLink } from 'react-router-dom';
import './PatientBooking.css';

const PatientDashboard = () => {
    const { user } = useAuth() as any;
    const { bookings, patients, invoices } = useApp() as any;

    const patientRecord = patients.find((p: any) => p.email === user?.email || p.id === user?.id);
    const patientBookings = bookings.filter((b: any) =>
        b.patientId === user?.id || b.email === user?.email
    ).sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    const patientInvoices = invoices.filter((inv: any) =>
        inv.patientId === user?.id || (patientRecord && inv.patientId === patientRecord.id)
    );

    const patientAssessments = patientRecord?.assessments || [];

    const nextAppointment = patientBookings.find((b: any) => b.status === 'Approved');

    return (
        <div className="patient-dashboard fade-in">
            <div className="page-header">
                <div>
                    <h1>Welcome back, {user?.name || 'Patient'}</h1>
                    <p>Manage your health journey and upcoming appointments.</p>
                </div>
                <NavLink to="/patient/book" className="btn btn-primary btn-with-icon">
                    <FiCalendar /> <span>Book New Appointment</span>
                </NavLink>
            </div>

            <div className="stats-grid mt-lg">
                <div className="stat-card">
                    <div className="stat-icon-square" style={{ background: '#3F46B815', color: '#3F46B8' }}><FiCalendar /></div>
                    <p className="stat-label">Total Bookings</p>
                    <h3 className="stat-value">{patientBookings.length}</h3>
                </div>
                <div className="stat-card">
                    <div className="stat-icon-square" style={{ background: '#10B98115', color: '#10B981' }}><FiActivity /></div>
                    <p className="stat-label">Last Status</p>
                    <h3 className="stat-value" style={{ fontSize: '1.25rem' }}>{patientBookings[0]?.status || 'No history'}</h3>
                </div>
            </div>

            <div className="quick-actions-grid mt-lg">
                <NavLink to="/patient" className="quick-action-card">
                    <div className="action-icon"><FiGrid /></div>
                    <span>Dashboard</span>
                </NavLink>
                <NavLink to="/patient/book" className="quick-action-card">
                    <div className="action-icon"><FiCalendar /></div>
                    <span>Book Appointment</span>
                </NavLink>
                <NavLink to="/patient/status" className="quick-action-card">
                    <div className="action-icon"><FiActivity /></div>
                    <span>Appointment Status</span>
                </NavLink>
                <NavLink to="/patient/help" className="quick-action-card">
                    <div className="action-icon"><FiInfo /></div>
                    <span>Help / Support</span>
                </NavLink>
            </div>

            <div className="dashboard-sections mt-lg">
                <div className="section-card card">
                    <h3>Upcoming Appointment</h3>
                    {nextAppointment ? (
                        <div className="next-booking mt-md p-md accent-bg radius-sm">
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <p className="text-secondary mb-xs">Date & Time</p>
                                    <strong>{nextAppointment.date} at {nextAppointment.time}</strong>
                                </div>
                                <div className="status-pill approved">Approved</div>
                            </div>
                        </div>
                    ) : (
                        <div className="empty-state mt-md">
                            <FiInfo />
                            <p>No upcoming approved appointments.</p>
                        </div>
                    )}
                </div>

                <div className="section-card card mt-lg">
                    <h3>Prescriptions & Reports</h3>
                    <div className="table-container mt-md">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Assessment</th>
                                    <th>Doctor</th>
                                    <th>Reports</th>
                                </tr>
                            </thead>
                            <tbody>
                                {patientAssessments.length > 0 ? patientAssessments.map((a: any) => (
                                    <tr key={a.id}>
                                        <td>{new Date(a.date).toLocaleDateString()}</td>
                                        <td>{a.templateName}</td>
                                        <td>Dr. Specialist</td>
                                        <td>
                                            <div className="action-btns">
                                                {a.data?.pharmacyOrder && <span className="status-pill pharmacy mr-xs" title={a.data.pharmacyOrder}>RX</span>}
                                                {a.data?.labOrder && <span className="status-pill laboratory mr-xs" title={a.data.labOrder}>LAB</span>}
                                                {a.data?.radiologyOrder && <span className="status-pill radiology" title={a.data.radiologyOrder}>RAD</span>}
                                            </div>
                                        </td>
                                    </tr>
                                )) : (
                                    <tr><td colSpan={4} className="text-center p-md">No medical records found.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="section-card card mt-lg">
                    <h3>Payment History</h3>
                    <div className="table-container mt-md">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Service</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {patientInvoices.length > 0 ? patientInvoices.map((inv: any) => (
                                    <tr key={inv.id}>
                                        <td>{inv.id}</td>
                                        <td>{inv.service}</td>
                                        <td>AED {inv.amount}</td>
                                        <td><span className={`status-pill ${inv.status.toLowerCase()}`}>{inv.status}</span></td>
                                        <td>{inv.date}</td>
                                    </tr>
                                )) : (
                                    <tr><td colSpan={5} className="text-center p-md">No payment history found.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PatientDashboard;
