import { FiHome, FiBox, FiUsers, FiTrendingUp, FiArrowUpRight } from 'react-icons/fi';
import { useApp } from '../../context/AppContext';
import './Dashboard.css';

const SuperAdminHome = () => {
    const { clinics, staff } = useApp() as any;

    const stats = [
        { label: 'Total Clinics', value: (clinics as any[]).length.toString(), icon: <FiHome />, color: '#23286B' },
        { label: 'Active Modules', value: '3', icon: <FiBox />, color: '#3F46B8' },
        { label: 'Total Admins', value: (staff as any[]).filter((s: any) => s.role === 'clinic_admin').length.toString(), icon: <FiUsers />, color: '#10B981' },
        { label: 'System Uptime', value: '99.9%', icon: <FiTrendingUp />, color: '#F59E0B' },
    ];

    return (
        <div className="dashboard-home">
            <div className="page-header">
                <div>
                    <h2>System Overview</h2>
                    <p>Manage all clinics and platform settings from here.</p>
                </div>
            </div>

            <div className="stats-grid">
                {stats.map((stat, index) => (
                    <div
                        key={index}
                        className={`stat-card ${index === 0 ? 'primary-border' : ''}`}
                    >
                        <div className="stat-icon-square" style={{ backgroundColor: `${stat.color}15`, color: stat.color }}>
                            {stat.icon}
                        </div>
                        <p className="stat-label">{stat.label}</p>
                        <h3 className="stat-value">{stat.value}</h3>
                        <div className="stat-trend positive">
                            <FiArrowUpRight /> 12%
                        </div>
                    </div>
                ))}
            </div>

            <div className="dashboard-sections grid-2">
                <div className="dashboard-section-card card">
                    <h3>Recent Clinics</h3>
                    <div className="dummy-list">
                        {(clinics as any[]).slice(0, 3).map((clinic: any) => (
                            <div key={clinic.id} className="list-item">
                                <span className="item-name">{clinic.name}</span>
                                <span className="item-status active">{clinic.status}</span>
                            </div>
                        ))}
                    </div>
                    <button className="text-link">View all clinics</button>
                </div>

                <div className="dashboard-section-card card">
                    <h3>System Alerts</h3>
                    <div className="dummy-list">
                        <div className="list-item alert">
                            <span className="item-name">Skaf Clinic storage near limit</span>
                            <span className="item-status warn">Warning</span>
                        </div>
                        <div className="list-item alert">
                            <span className="item-name">Main server backup completed</span>
                            <span className="item-status ok">Info</span>
                        </div>
                    </div>
                    <button className="text-link">View logs</button>
                </div>
            </div>
        </div>
    );
};

export default SuperAdminHome;
