import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiUsers, FiActivity, FiPlus, FiCopy, FiEdit, FiAlertCircle, FiPackage, FiInfo, FiArrowUpRight } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import './Dashboard.css';

const ClinicAdminHome = () => {
    const navigate = useNavigate();
    const { selectedClinic } = useAuth() as any;
    const { staff, bookings, clinics } = useApp() as any;
    const [copySuccess, setCopySuccess] = useState(false);

    // Get current clinic data
    const currentClinic = clinics.find((c: any) => c.id === selectedClinic?.id) || selectedClinic;

    // Filter data for current clinic
    const clinicStaff = (staff as any[]).filter(s => s.clinicId === currentClinic?.id || s.clinics?.includes(currentClinic?.id));
    const doctors = clinicStaff.filter(s => s.role === 'doctor');
    const todayBookings = (bookings as any[]).filter(b => {
        const today = new Date().toISOString().split('T')[0];
        return b.clinicId === currentClinic?.id && b.date === today;
    });

    // Get enabled modules
    const enabledModules = currentClinic?.modules ? Object.entries(currentClinic.modules).filter(([_, enabled]) => enabled) : [];
    const disabledModules = currentClinic?.modules ? Object.entries(currentClinic.modules).filter(([_, enabled]) => !enabled) : [];

    const stats = [
        { label: 'Total Doctors', value: doctors.length.toString(), icon: <FiUsers />, color: '#23286B' },
        { label: 'Total Staff', value: clinicStaff.length.toString(), icon: <FiUsers />, color: '#3F46B8' },
        { label: "Today's Appointments", value: todayBookings.length.toString(), icon: <FiActivity />, color: '#10B981' },
        { label: 'Active Modules', value: enabledModules.length.toString(), icon: <FiPackage />, color: '#F59E0B' },
    ];

    const handleCopyBookingLink = () => {
        const bookingUrl = `${window.location.origin}/book/${currentClinic?.id}`;
        navigator.clipboard.writeText(bookingUrl);
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
    };

    return (
        <div className="dashboard-home">
            <div className="dashboard-welcome">
                <div>
                    <h2>{currentClinic?.name || 'Clinic'} Dashboard</h2>
                    <p>Welcome back! Here's what's happening at your facility today.</p>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="stats-grid">
                {stats.map((stat, index) => (
                    <div
                        key={index}
                        className={`stat-card ${index === 0 ? 'primary-border' : ''}`}
                    >
                        <div className="stat-icon-square" style={{ backgroundColor: `${stat.color}15`, color: stat.color }}>
                            {stat.icon}
                        </div>
                        <p className="stat-label">{stat.label}</p>
                        <h3 className="stat-value">{stat.value}</h3>
                        <div className="stat-trend positive">
                            <FiArrowUpRight /> 12%
                        </div>
                    </div>
                ))}
            </div>

            {/* Quick Actions */}
            <div className="quick-actions-section card">
                <h3>Quick Actions</h3>
                <div className="quick-actions-grid">
                    <button className="quick-action-btn primary-action" onClick={() => navigate('/clinic-admin/staff')}>
                        <FiPlus size={24} />
                        <span>Add Staff</span>
                    </button>
                    <button className="quick-action-btn" onClick={() => navigate('/clinic-admin/forms')}>
                        <FiEdit size={24} />
                        <span>Edit Forms</span>
                    </button>
                    <button className="quick-action-btn" onClick={handleCopyBookingLink}>
                        <FiCopy size={24} />
                        <span>{copySuccess ? 'Link Copied!' : 'Copy Booking Link'}</span>
                    </button>
                </div>
            </div>

            {/* Alerts */}
            {disabledModules.length > 0 && (
                <div className="alerts-section">
                    <div className="alert alert-minimal warning">
                        <FiAlertCircle size={20} />
                        <div className="alert-content">
                            <strong>Disabled Modules</strong>
                            <p>{disabledModules.length} module(s) are currently disabled: {disabledModules.map(([name]) => name).join(', ')}</p>
                        </div>
                    </div>
                </div>
            )}

            <div className="dashboard-sections grid-2">
                <div className="dashboard-section-card card">
                    <h3>Recent Staff</h3>
                    <div className="dummy-list">
                        {clinicStaff.slice(0, 5).map((s: any) => (
                            <div key={s.id} className="list-item-minimal">
                                <div>
                                    <span className="item-name">{s.name}</span>
                                    <span className="info-subtext">{s.role}</span>
                                </div>
                                <FiInfo className="info-icon-small" />
                            </div>
                        ))}
                    </div>
                </div>

                <div className="dashboard-section-card card">
                    <h3>Enabled Modules</h3>
                    <div className="modules-list-refined">
                        {enabledModules.length > 0 ? (
                            enabledModules.map(([name, _]) => (
                                <div key={name} className="module-row-minimal">
                                    <div className="module-main">
                                        <FiPackage />
                                        <span>{name.charAt(0).toUpperCase() + name.slice(1)}</span>
                                    </div>
                                    <span className="status-pill active-minimal">Active</span>
                                </div>
                            ))
                        ) : (
                            <p className="empty-message">No modules enabled</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ClinicAdminHome;
