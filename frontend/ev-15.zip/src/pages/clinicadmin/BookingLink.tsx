import { useState } from 'react';
import { FiCopy, FiCheck, FiExternalLink, FiShare2, FiToggleLeft, FiToggleRight, FiCalendar, FiClock, FiUsers } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import './BookingLink.css';

const BookingLink = () => {
    const { selectedClinic } = useAuth() as any;
    const { staff, clinics } = useApp() as any;
    const [copied, setCopied] = useState(false);
    const [bookingEnabled, setBookingEnabled] = useState(true);

    // Get current clinic
    const currentClinic = clinics.find((c: any) => c.id === selectedClinic?.id) || selectedClinic;

    // Get clinic doctors
    const clinicDoctors = (staff as any[]).filter(s =>
        (s.clinicId === currentClinic?.id || s.clinics?.includes(currentClinic?.id)) &&
        s.role === 'doctor' &&
        s.status === 'active'
    );

    const [config, setConfig] = useState({
        selectedDoctors: clinicDoctors.map((d: any) => d.id),
        services: ['Consultation', 'Follow-up', 'Emergency'],
        timeSlots: ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'],
        offDays: [0, 6], // Sunday, Saturday
        holidays: [] as string[]
    });

    const bookingUrl = `${window.location.origin}/book/${currentClinic?.id || 'clinic'}`;

    const copyToClipboard = () => {
        navigator.clipboard.writeText(bookingUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const shareOnWhatsApp = () => {
        const message = `Book your appointment at ${currentClinic?.name}: ${bookingUrl}`;
        window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
    };

    const getEmbedCode = () => {
        return `<iframe src="${bookingUrl}" width="100%" height="600" frameborder="0"></iframe>`;
    };

    const copyEmbedCode = () => {
        navigator.clipboard.writeText(getEmbedCode());
        alert('Embed code copied to clipboard!');
    };

    const toggleDoctor = (doctorId: number) => {
        setConfig(prev => ({
            ...prev,
            selectedDoctors: prev.selectedDoctors.includes(doctorId)
                ? prev.selectedDoctors.filter(id => id !== doctorId)
                : [...prev.selectedDoctors, doctorId]
        }));
    };

    const toggleOffDay = (day: number) => {
        setConfig(prev => ({
            ...prev,
            offDays: prev.offDays.includes(day)
                ? prev.offDays.filter(d => d !== day)
                : [...prev.offDays, day]
        }));
    };

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    return (
        <div className="booking-link-page">
            <div className="page-header">
                <div>
                    <h1>Booking Link Generator</h1>
                    <p>Configure and share your clinic's online booking link with patients.</p>
                </div>
                <button
                    className={`btn ${bookingEnabled ? 'btn-danger' : 'btn-success'} btn-with-icon`}
                    onClick={() => setBookingEnabled(!bookingEnabled)}
                >
                    {bookingEnabled ? <FiToggleRight /> : <FiToggleLeft />}
                    <span>{bookingEnabled ? 'Disable Booking' : 'Enable Booking'}</span>
                </button>
            </div>

            {/* Booking Link Card */}
            <div className="booking-card card">
                <div className="card-header">
                    <div className="link-icon">
                        <FiShare2 size={32} />
                    </div>
                    <div>
                        <h3>Your Unique Booking Link</h3>
                        <p>Share this link to allow patients to book appointments online</p>
                    </div>
                    <span className={`status-pill ${bookingEnabled ? 'active' : 'inactive'}`}>
                        {bookingEnabled ? 'Active' : 'Disabled'}
                    </span>
                </div>

                <div className="url-container">
                    <div className="url-box">{bookingUrl}</div>
                    <button className={`copy-btn ${copied ? 'copied' : ''}`} onClick={copyToClipboard}>
                        {copied ? <FiCheck /> : <FiCopy />}
                        <span>{copied ? 'Copied!' : 'Copy'}</span>
                    </button>
                </div>

                <div className="link-actions">
                    <button className="btn btn-secondary btn-with-icon" onClick={() => window.open(bookingUrl, '_blank')}>
                        <FiExternalLink />
                        <span>Preview Link</span>
                    </button>
                    <button className="btn btn-secondary btn-with-icon" onClick={shareOnWhatsApp}>
                        <FiShare2 />
                        <span>Share on WhatsApp</span>
                    </button>
                    <button className="btn btn-secondary btn-with-icon" onClick={copyEmbedCode}>
                        <FiCopy />
                        <span>Get Embed Code</span>
                    </button>
                </div>
            </div>

            {/* Configuration Sections */}
            <div className="config-grid">
                {/* Doctor Selection */}
                <div className="config-card card">
                    <div className="config-header">
                        <FiUsers />
                        <h3>Available Doctors</h3>
                    </div>
                    <p className="config-desc">Select which doctors patients can book with</p>
                    <div className="doctor-list">
                        {clinicDoctors.length > 0 ? clinicDoctors.map((doctor: any) => (
                            <label key={doctor.id} className="checkbox-item">
                                <input
                                    type="checkbox"
                                    checked={config.selectedDoctors.includes(doctor.id)}
                                    onChange={() => toggleDoctor(doctor.id)}
                                />
                                <span>{doctor.name}</span>
                                <span className="specialty">{doctor.specialty || doctor.department || 'General'}</span>
                            </label>
                        )) : (
                            <p className="empty-message">No doctors available</p>
                        )}
                    </div>
                </div>

                {/* Time Slots */}
                <div className="config-card card">
                    <div className="config-header">
                        <FiClock />
                        <h3>Time Slots</h3>
                    </div>
                    <p className="config-desc">Configure available appointment times</p>
                    <div className="time-slots-grid">
                        {config.timeSlots.map((slot, index) => (
                            <div key={index} className="time-slot-chip">
                                {slot}
                            </div>
                        ))}
                    </div>
                    <button className="btn btn-sm btn-secondary mt-md">
                        + Add Time Slot
                    </button>
                </div>

                {/* Off Days */}
                <div className="config-card card">
                    <div className="config-header">
                        <FiCalendar />
                        <h3>Off Days</h3>
                    </div>
                    <p className="config-desc">Select days when clinic is closed</p>
                    <div className="days-grid">
                        {days.map((day, index) => (
                            <label key={index} className={`day-chip ${config.offDays.includes(index) ? 'off' : ''}`}>
                                <input
                                    type="checkbox"
                                    checked={config.offDays.includes(index)}
                                    onChange={() => toggleOffDay(index)}
                                />
                                <span>{day.substring(0, 3)}</span>
                            </label>
                        ))}
                    </div>
                </div>

                {/* Services */}
                <div className="config-card card">
                    <div className="config-header">
                        <FiShare2 />
                        <h3>Services</h3>
                    </div>
                    <p className="config-desc">Services available for booking</p>
                    <div className="services-list">
                        {config.services.map((service, index) => (
                            <div key={index} className="service-chip">
                                {service}
                            </div>
                        ))}
                    </div>
                    <button className="btn btn-sm btn-secondary mt-md">
                        + Add Service
                    </button>
                </div>
            </div>

            {/* Save Button */}
            <div className="save-section">
                <button className="btn btn-primary btn-lg">
                    <FiCheck />
                    Save Configuration
                </button>
            </div>
        </div>
    );
};

export default BookingLink;
